import React from "react";
import { Provider as PaperProvider } from "react-native-paper";
import Toast from "react-native-toast-message";

import { AuthProvider } from "./src/context/AuthContext";
import AppNavigator from "./src/navigation/AppNavigator";

export default function App() {
  return (
    <PaperProvider>
      <AuthProvider>
        <AppNavigator />
        <Toast />
      </AuthProvider>
    </PaperProvider>
  );
}