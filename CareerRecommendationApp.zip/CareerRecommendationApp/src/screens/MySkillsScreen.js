import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Alert,
  ActivityIndicator,
} from "react-native";

import { Button, Card } from "react-native-paper";

import { Picker } from "@react-native-picker/picker";

import api from "../api/api";
import COLORS from "../constants/colors";
import { getToken } from "../utils/storage";

export default function MySkillsScreen() {
  const [skills, setSkills] = useState([]);
  const [mySkills, setMySkills] = useState([]);

  const [selectedSkill, setSelectedSkill] = useState("");

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    try {
      setLoading(true);

      const token = await getToken();

      const headers = {
        Authorization: `Bearer ${token}`,
      };

      const [skillRes, mySkillRes] = await Promise.all([
        api.get("/skills"),
        api.get("/skills/my-skills", { headers }),
      ]);

      setSkills(skillRes.data);
      setMySkills(mySkillRes.data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  }

  async function addSkill() {
    if (!selectedSkill) {
      Alert.alert("Select Skill", "Please select a skill.");

      return;
    }

    const exists = mySkills.find(
      (item) => String(item.skill_id) === String(selectedSkill),
    );

    if (exists) {
      Alert.alert("Already Added", "This skill already exists.");

      return;
    }

    try {
      const token = await getToken();

      await api.post(
        "/skills/user-skill",
        {
          skill_id: selectedSkill,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      setSelectedSkill("");

      loadData();
    } catch (error) {
      Alert.alert("Error", "Unable to add skill.");
    }
  }

  async function removeSkill(id) {
    try {
      const token = await getToken();

      await api.delete(`/skills/my-skills/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      loadData();
    } catch (error) {
      Alert.alert("Error", "Unable to remove skill.");
    }
  }

  function renderItem({ item, index }) {
    return (
      <Card style={styles.card}>
        <Card.Content>
          <View style={styles.row}>
            <View>
              <Text style={styles.skillName}>{item.skill_name}</Text>

              <Text style={styles.skillText}>Skill #{index + 1}</Text>
            </View>

            <Button
              mode="contained"
              buttonColor="#EF4444"
              onPress={() => removeSkill(item.id)}
            >
              Remove
            </Button>
          </View>
        </Card.Content>
      </Card>
    );
  }

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />

        <Text style={styles.loadingText}>Loading Skills...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>My Skills</Text>

      <Picker
        selectedValue={selectedSkill}
        onValueChange={(value) => setSelectedSkill(value)}
        style={styles.picker}
      >
        <Picker.Item label="Select Skill" value="" />

        {skills.map((item) => (
          <Picker.Item
            key={`picker-${item.id}`}
            label={item.skill_name}
            value={item.id}
          />
        ))}
      </Picker>

      <Button mode="contained" style={styles.addButton} onPress={addSkill}>
        Add Skill
      </Button>

      <FlatList
        data={mySkills}
        renderItem={renderItem}
        keyExtractor={(item, index) => `${item.id}-${index}`}
        contentContainerStyle={{
          paddingBottom: 20,
        }}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No Skills Added Yet</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#F5F7FA",
    padding: 18,
  },

  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },

  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#666",
  },

  heading: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#111827",
    marginBottom: 20,
  },

  picker: {
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    marginBottom: 15,
  },

  addButton: {
    borderRadius: 12,
    paddingVertical: 6,
    backgroundColor: "#2563EB",
    marginBottom: 20,
  },

  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    marginBottom: 12,
    elevation: 3,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  skillName: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },

  skillText: {
    marginTop: 4,
    color: "#6B7280",
    fontSize: 13,
  },

  emptyContainer: {
    marginTop: 40,
    alignItems: "center",
  },

  emptyText: {
    fontSize: 16,
    color: "#9CA3AF",
  },
});
