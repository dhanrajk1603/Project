import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";

import { MaterialCommunityIcons } from "@expo/vector-icons";

import api from "../api/api";
import COLORS from "../constants/colors";
import Header from "../components/Header";
import { getToken } from "../utils/storage";

export default function DashboardScreen({ navigation }) {
  const [profile, setProfile] = useState({});

  const [skills, setSkills] = useState([]);

  const [jobs, setJobs] = useState([]);

  const [courses, setCourses] = useState([]);

  const [myCourses, setMyCourses] = useState([]);

  const [myApplications, setMyApplications] = useState([]);

  const [loading, setLoading] = useState(true);

  const [refreshing, setRefreshing] = useState(false);

  const [error, setError] = useState("");

  useEffect(() => {
    loadDashboard();
  }, []);

  async function loadDashboard() {
    try {
      setLoading(true);
      setError("");

      const token = await getToken();

      const headers = {
        Authorization: `Bearer ${token}`,
      };

      const [
        profileRes,
        skillsRes,
        jobsRes,
        coursesRes,
        myCoursesRes,
        myApplicationsRes,
      ] = await Promise.all([
        api.get("/users/profile", { headers }),
        api.get("/skills/my-skills", { headers }),
        api.get("/jobs"),
        api.get("/courses"),
        api.get("/enrollments/my-courses", { headers }),
        api.get("/job-applications/my-applications", { headers }),
      ]);

      setProfile(profileRes.data);

      setSkills(skillsRes.data);

      setJobs(jobsRes.data);

      setCourses(coursesRes.data);

      setMyCourses(myCoursesRes.data);

      setMyApplications(myApplicationsRes.data);
    } catch (e) {
      console.log(e);
      setError("We couldn't refresh your dashboard. Please check your connection and try again.");
    } finally {
      setLoading(false);

      setRefreshing(false);
    }
  }

  const onRefresh = () => {
    setRefreshing(true);

    loadDashboard();
  };

  if (loading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />

        <Text style={styles.loadingText}>Loading Dashboard...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        <Header user={profile} />

        {error ? (
          <View style={styles.errorCard}>
            <MaterialCommunityIcons name="wifi-off" size={22} color={COLORS.danger} />
            <View style={styles.errorCopy}>
              <Text style={styles.errorTitle}>Unable to update dashboard</Text>
              <Text style={styles.errorText}>{error}</Text>
            </View>
            <TouchableOpacity onPress={loadDashboard} accessibilityLabel="Retry loading dashboard">
              <Text style={styles.retryText}>Retry</Text>
            </TouchableOpacity>
          </View>
        ) : null}

        {/* Welcome Card */}

        <View style={styles.welcomeCard}>
          <View style={styles.welcomeTopRow}>
            <Text style={styles.welcomeEyebrow}>YOUR CAREER SPACE</Text>
            <View style={styles.readyBadge}>
              <View style={styles.readyDot} />
              <Text style={styles.readyText}>On track</Text>
            </View>
          </View>
          <Text style={styles.welcomeTitle}>Career Progress 🚀</Text>

          <Text style={styles.welcomeSubtitle}>
            Every skill and application brings you closer to your next role.
          </Text>

          <View style={styles.statsRow}>
            <View style={styles.statBox}>
              <Text style={styles.statNumber}>{skills.length}</Text>

              <Text style={styles.statLabel}>Skills</Text>
            </View>

            <View style={styles.statBox}>
              <Text style={styles.statNumber}>{myCourses.length}</Text>

              <Text style={styles.statLabel}>Courses</Text>
            </View>

            <View style={styles.statBox}>
              <Text style={styles.statNumber}>{myApplications.length}</Text>

              <Text style={styles.statLabel}>Applied</Text>
            </View>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Overview</Text>

        <View style={styles.grid}>
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("MySkills")}
            accessibilityLabel="Manage my skills"
          >
            <MaterialCommunityIcons name="brain" color="#2196F3" size={32} />

            <Text style={styles.cardValue}>{skills.length}</Text>

            <Text style={styles.cardTitle}>Skills</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("MyAppliedJobs")}
            accessibilityLabel="View applied jobs"
          >
            <MaterialCommunityIcons
              name="briefcase-check"
              color="#16A34A"
              size={32}
            />

            <Text style={styles.cardValue}>{myApplications.length}</Text>

            <Text style={styles.cardTitle}>Applied Jobs</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate("MyCourses")}
            accessibilityLabel="View my courses"
          >
            <MaterialCommunityIcons
              name="book-open-page-variant"
              color="#F59E0B"
              size={32}
            />

            <Text style={styles.cardValue}>{myCourses.length}</Text>

            <Text style={styles.cardTitle}>My Courses</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate("Profile")} accessibilityLabel="Edit profile">
            <MaterialCommunityIcons
              name="account-circle"
              color="#8B5CF6"
              size={32}
            />

            <Text style={styles.cardValue}>Edit</Text>

            <Text style={styles.cardTitle}>Profile</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <Text style={styles.sectionHint}>What would you like to do?</Text>
        </View>

        <TouchableOpacity style={[styles.actionCard, { backgroundColor: "#7C3AED" }]} onPress={() => navigation.navigate("AICareer")}>
          <MaterialCommunityIcons name="creation" size={28} color="#fff" />
          <Text style={styles.actionText}>AI Career Advice</Text>
          <MaterialCommunityIcons name="chevron-right" size={28} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity style={[styles.actionCard, { backgroundColor: "#0F766E" }]} onPress={() => navigation.navigate("MyPayments")}>
          <MaterialCommunityIcons name="receipt-text" size={28} color="#fff" />
          <Text style={styles.actionText}>My Payments</Text>
          <MaterialCommunityIcons name="chevron-right" size={28} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionCard}
          onPress={() => navigation.navigate("MySkills")}
        >
          <MaterialCommunityIcons name="star-circle" size={28} color="#fff" />

          <Text style={styles.actionText}>Manage My Skills</Text>

          <MaterialCommunityIcons name="chevron-right" size={28} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionCard, { backgroundColor: "#16A34A" }]}
          onPress={() => navigation.navigate("Jobs")}
        >
          <MaterialCommunityIcons
            name="briefcase-search"
            size={28}
            color="#fff"
          />

          <Text style={styles.actionText}>Explore Jobs</Text>

          <MaterialCommunityIcons name="chevron-right" size={28} color="#fff" />
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionCard, { backgroundColor: "#EA580C" }]}
          onPress={() => navigation.navigate("Courses")}
        >
          <MaterialCommunityIcons name="book-search" size={28} color="#fff" />

          <Text style={styles.actionText}>Explore Courses</Text>

          <MaterialCommunityIcons name="chevron-right" size={28} color="#fff" />
        </TouchableOpacity>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Latest Jobs</Text>

          <TouchableOpacity onPress={() => navigation.navigate("Jobs")}>
            <Text style={styles.viewAll}>View All</Text>
          </TouchableOpacity>
        </View>

        {jobs.slice(0, 2).map((item) => (
          <TouchableOpacity key={item.id} style={styles.jobCard}>
            <View style={styles.jobIcon}>
              <MaterialCommunityIcons name="briefcase" size={28} color="#fff" />
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.jobTitle}>{item.title}</Text>

              <Text style={styles.jobCompany}>{item.company}</Text>

              <Text style={styles.jobLocation}>📍 {item.location}</Text>
            </View>
          </TouchableOpacity>
        ))}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Latest Courses</Text>

          <TouchableOpacity onPress={() => navigation.navigate("Courses")}>
            <Text style={styles.viewAll}>View All</Text>
          </TouchableOpacity>
        </View>

        {courses.slice(0, 2).map((item) => (
          <TouchableOpacity key={item.id} style={styles.courseCard}>
            <View style={styles.courseIcon}>
              <MaterialCommunityIcons
                name="book-open-page-variant"
                size={28}
                color="#fff"
              />
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.jobTitle}>{item.title}</Text>

              <Text style={styles.jobCompany}>{item.category_name}</Text>

              <Text style={styles.jobLocation}>₹ {item.price}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F8FAFC",
  },

  container: {
    flex: 1,
    backgroundColor: "#F8FAFC",
    paddingHorizontal: 18,
    paddingTop: 10,
  },

  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F8FAFC",
  },

  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: "#666",
  },

  errorCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FEF2F2",
    borderColor: "#FECACA",
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    marginBottom: 16,
  },

  errorCopy: {
    flex: 1,
    marginLeft: 10,
    marginRight: 8,
  },

  errorTitle: {
    color: "#991B1B",
    fontSize: 14,
    fontWeight: "700",
  },

  errorText: {
    color: "#B91C1C",
    fontSize: 12,
    lineHeight: 17,
    marginTop: 3,
  },

  retryText: {
    color: COLORS.danger,
    fontSize: 13,
    fontWeight: "700",
  },

  /* Welcome Card */

  welcomeCard: {
    backgroundColor: "#18234A",
    borderRadius: 24,
    padding: 22,
    marginBottom: 28,
    elevation: 8,
    shadowColor: "#172554",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.16,
    shadowRadius: 16,
  },

  welcomeTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  welcomeEyebrow: {
    color: "#A5B4FC",
    fontSize: 10,
    fontWeight: "800",
    letterSpacing: 1.2,
  },

  readyBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255,255,255,0.12)",
    borderRadius: 99,
    paddingHorizontal: 9,
    paddingVertical: 5,
  },

  readyDot: {
    height: 6,
    width: 6,
    borderRadius: 99,
    backgroundColor: "#5EEAD4",
    marginRight: 5,
  },

  readyText: {
    color: "#E0E7FF",
    fontSize: 10,
    fontWeight: "700",
  },

  welcomeTitle: {
    color: "#FFFFFF",
    fontSize: 26,
    fontWeight: "800",
    letterSpacing: -0.5,
    marginTop: 15,
  },

  welcomeSubtitle: {
    color: "#C7D2FE",
    marginTop: 8,
    fontSize: 14,
    lineHeight: 20,
  },

  statsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 22,
  },

  statBox: {
    backgroundColor: "rgba(255,255,255,0.1)",
    borderRadius: 14,
    alignItems: "center",
    paddingVertical: 13,
    width: "31%",
  },

  statNumber: {
    color: "#FFFFFF",
    fontSize: 22,
    fontWeight: "800",
  },

  statLabel: {
    color: "#C7D2FE",
    marginTop: 5,
    fontSize: 11,
    fontWeight: "600",
  },

  /* Section */

  sectionTitle: {
    fontSize: 19,
    fontWeight: "800",
    color: "#172033",
    marginBottom: 13,
    marginTop: 0,
  },

  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    marginBottom: 12,
  },

  card: {
    width: "48%",
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: "#334155",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
    borderWidth: 1,
    borderColor: "#EDF1F7",
    minHeight: 126,
  },

  cardValue: {
    fontSize: 25,
    fontWeight: "800",
    marginTop: 10,
    color: "#172033",
  },

  cardTitle: {
    marginTop: 2,
    color: "#64748B",
    fontSize: 12,
  },

  actionCard: {
    backgroundColor: "#4F46E5",
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    elevation: 3,
    shadowColor: "#3730A3",
    shadowOpacity: 0.16,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },

  actionText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "700",
    flex: 1,
    marginLeft: 15,
  },

  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 8,
  },

  sectionHint: {
    color: "#94A3B8",
    fontSize: 11,
    marginBottom: 13,
  },

  viewAll: {
    color: "#2563EB",
    fontWeight: "700",
  },

  jobCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 15,
    marginBottom: 12,
    flexDirection: "row",
    alignItems: "center",
    elevation: 3,
  },

  courseCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 15,
    marginBottom: 20,
    flexDirection: "row",
    alignItems: "center",
    elevation: 3,
  },

  jobIcon: {
    width: 55,
    height: 55,
    borderRadius: 15,
    backgroundColor: "#2563EB",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },

  courseIcon: {
    width: 55,
    height: 55,
    borderRadius: 15,
    backgroundColor: "#F59E0B",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },

  jobTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: "#222",
  },

  jobCompany: {
    color: "#666",
    marginTop: 2,
  },

  jobLocation: {
    color: "#999",
    marginTop: 3,
  },
});
