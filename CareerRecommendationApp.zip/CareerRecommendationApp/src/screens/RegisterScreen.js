import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from "react-native";

import { TextInput, Button, Card } from "react-native-paper";
import Toast from "react-native-toast-message";

import api from "../api/api";
import COLORS from "../constants/colors";

export default function RegisterScreen({ navigation }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [loading, setLoading] = useState(false);

  async function register() {
    if (!name || !email || !mobile || !password || !confirmPassword) {
      Toast.show({
        type: "error",
        text1: "Please fill all fields",
      });

      return;
    }

    if (password !== confirmPassword) {
      Toast.show({
        type: "error",
        text1: "Passwords do not match",
      });

      return;
    }

    try {
      setLoading(true);

      await api.post("/auth/register", {
        name,
        email,
        mobile,
        password,
      });

      Toast.show({
        type: "success",
        text1: "Registration Successful",
      });

      navigation.replace("Login");
    } catch (error) {
      Toast.show({
        type: "error",
        text1: error.response?.data?.message || "Registration Failed",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.title}>Create Account</Text>

          <Text style={styles.subtitle}>Register to continue</Text>

          <TextInput
            label="Full Name"
            mode="outlined"
            value={name}
            onChangeText={setName}
            style={styles.input}
          />

          <TextInput
            label="Email"
            mode="outlined"
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={setEmail}
            style={styles.input}
          />

          <TextInput
            label="Mobile"
            mode="outlined"
            keyboardType="phone-pad"
            value={mobile}
            onChangeText={setMobile}
            style={styles.input}
          />

          <TextInput
            label="Password"
            mode="outlined"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            style={styles.input}
          />

          <TextInput
            label="Confirm Password"
            mode="outlined"
            secureTextEntry
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            style={styles.input}
          />

          <Button
            mode="contained"
            loading={loading}
            onPress={register}
            style={styles.button}
          >
            Register
          </Button>

          <TouchableOpacity onPress={() => navigation.replace("Login")}>
            <Text style={styles.footer}>Already have an account? Login</Text>
          </TouchableOpacity>
        </Card.Content>
      </Card>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: "center",
    padding: 20,
  },

  card: {
    borderRadius: 20,
    elevation: 5,
    paddingVertical: 20,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    color: COLORS.primary,
    marginBottom: 5,
  },

  subtitle: {
    textAlign: "center",
    color: COLORS.text,
    marginBottom: 25,
    fontSize: 16,
  },

  input: {
    marginBottom: 15,
  },

  button: {
    marginTop: 10,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: COLORS.primary,
  },

  footer: {
    marginTop: 20,
    textAlign: "center",
    color: COLORS.primary,
    fontWeight: "600",
    fontSize: 15,
  },
});
