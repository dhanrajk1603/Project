import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";

import { SafeAreaView } from "react-native-safe-area-context";
import { Searchbar, Card, Button } from "react-native-paper";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import api from "../api/api";
import COLORS from "../constants/colors";

export default function JobsScreen({ navigation }) {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchJobs();
  }, []);

  async function fetchJobs() {
    try {
      setLoading(true);

      const res = await api.get("/jobs");

      setJobs(res.data);
      setFilteredJobs(res.data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function onRefresh() {
    setRefreshing(true);
    fetchJobs();
  }

  function searchJobs(text) {
    setSearch(text);

    if (text.trim() === "") {
      setFilteredJobs(jobs);
      return;
    }

    const result = jobs.filter((job) => {
      return (
        job.title.toLowerCase().includes(text.toLowerCase()) ||
        job.company.toLowerCase().includes(text.toLowerCase()) ||
        job.location.toLowerCase().includes(text.toLowerCase())
      );
    });

    setFilteredJobs(result);
  }

  function renderItem({ item }) {
    return (
      <Card style={styles.card}>
        <Card.Content>
          <View style={styles.headerRow}>
            <View style={styles.iconBox}>
              <MaterialCommunityIcons name="briefcase" size={28} color="#fff" />
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.title}>{item.title}</Text>

              <Text style={styles.company}>{item.company}</Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <MaterialCommunityIcons
              name="map-marker"
              size={18}
              color="#EF4444"
            />

            <Text style={styles.info}>{item.location}</Text>
          </View>

          <View style={styles.infoRow}>
            <MaterialCommunityIcons
              name="currency-inr"
              size={18}
              color="#16A34A"
            />

            <Text style={styles.info}>{item.salary}</Text>
          </View>

          <Text numberOfLines={2} style={styles.description}>
            {item.description}
          </Text>

          <Button
            mode="contained"
            style={styles.button}
            onPress={() =>
              navigation.navigate("JobDetails", {
                job: item,
              })
            }
          >
            View Details
          </Button>
        </Card.Content>
      </Card>
    );
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />

        <Text style={styles.loadingText}>Loading Jobs...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <View style={styles.container}>
        <Searchbar
          placeholder="Search Jobs..."
          value={search}
          onChangeText={searchJobs}
          style={styles.search}
        />

        <FlatList
          data={filteredJobs}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          contentContainerStyle={{
            paddingBottom: 20,
          }}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <MaterialCommunityIcons
                name="briefcase-remove"
                size={60}
                color="#9CA3AF"
              />

              <Text style={styles.emptyTitle}>No Jobs Found</Text>

              <Text style={styles.emptySubtitle}>
                Try searching with another keyword.
              </Text>
            </View>
          }
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F7FA",
  },

  container: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 10,
  },

  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F7FA",
  },

  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: "#6B7280",
  },

  search: {
    borderRadius: 14,
    marginBottom: 18,
  },

  card: {
    borderRadius: 18,
    marginBottom: 15,
    elevation: 3,
    backgroundColor: "#FFFFFF",
  },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  iconBox: {
    width: 55,
    height: 55,
    borderRadius: 15,
    backgroundColor: "#2563EB",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },

  title: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },

  company: {
    marginTop: 3,
    fontSize: 15,
    color: "#6B7280",
  },

  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },

  info: {
    marginLeft: 8,
    color: "#374151",
    fontSize: 15,
  },

  description: {
    marginTop: 8,
    color: "#4B5563",
    lineHeight: 22,
  },

  button: {
    marginTop: 18,
    borderRadius: 12,
    backgroundColor: "#2563EB",
    paddingVertical: 5,
  },

  emptyContainer: {
    marginTop: 80,
    alignItems: "center",
    justifyContent: "center",
  },

  emptyTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#374151",
    marginTop: 15,
  },

  emptySubtitle: {
    marginTop: 6,
    color: "#9CA3AF",
    fontSize: 15,
  },
});
