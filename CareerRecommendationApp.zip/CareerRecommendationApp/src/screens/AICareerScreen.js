import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Card } from "react-native-paper";
import api from "../api/api";
import COLORS from "../constants/colors";
import { getToken } from "../utils/storage";

const Section = ({ title, children }) => (
  <Card style={styles.card}>
    <Card.Content>
      <Text style={styles.title}>{title}</Text>
      {children}
    </Card.Content>
  </Card>
);
const List = ({ items = [] }) => (
  <View>
    {items.map((item, index) => (
      <Text key={`${item}-${index}`} style={styles.item}>
        • {item}
      </Text>
    ))}
  </View>
);

export default function AICareerScreen() {
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const load = async () => {
    try {
      const token = await getToken();
      const headers = { Authorization: `Bearer ${token}` };
      const [advice, summary, gap, roadmap, questions, score] =
        await Promise.all(
          [
            "career-advice",
            "profile-summary",
            "skill-gap",
            "roadmap",
            "interview-questions",
            "career-score",
          ].map((path) => api.get(`/ai/${path}`, { headers })),
        );
      setData({
        advice: advice.data,
        summary: summary.data,
        gap: gap.data,
        roadmap: roadmap.data,
        questions: questions.data,
        score: score.data,
      });
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  useEffect(() => {
    load();
  }, []);
  if (loading)
    return (
      <View style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView
        contentContainerStyle={styles.container}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              load();
            }}
          />
        }
      >
        <Section title={`Career Score: ${data.score?.score ?? "—"}/100`}>
          <Text style={styles.copy}>{data.score?.nextStep}</Text>
        </Section>
        <Section title="Today's AI Advice">
          <List items={data.advice?.advice} />
        </Section>
        <Section title="Professional Summary">
          <Text style={styles.copy}>{data.summary?.summary}</Text>
        </Section>
        <Section title="Skill Gap">
          <Text style={styles.label}>Current skills</Text>
          <List items={data.gap?.currentSkills} />
          <Text style={styles.label}>Suggested next skills</Text>
          <List items={data.gap?.suggestedSkills} />
        </Section>
        <Section title="Learning Roadmap">
          <List items={data.roadmap?.roadmap} />
        </Section>
        <Section title="Interview Practice">
          <List items={data.questions?.questions} />
        </Section>
      </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F7FA" },
  container: { padding: 16, paddingBottom: 28 },
  loader: { flex: 1, alignItems: "center", justifyContent: "center" },
  card: { marginBottom: 14, borderRadius: 16, backgroundColor: "#fff" },
  title: {
    fontSize: 18,
    fontWeight: "700",
    color: "#172033",
    marginBottom: 10,
  },
  copy: { fontSize: 15, lineHeight: 22, color: "#475569" },
  item: { fontSize: 15, lineHeight: 23, color: "#475569", marginBottom: 3 },
  label: { fontWeight: "700", color: "#1E3A8A", marginTop: 8, marginBottom: 3 },
});
