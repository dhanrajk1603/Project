import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  ActivityIndicator,
} from "react-native";

import { Searchbar, Card, Button } from "react-native-paper";

import { MaterialCommunityIcons } from "@expo/vector-icons";

import api from "../api/api";
import COLORS from "../constants/colors";

export default function CoursesScreen({ navigation }) {
  const [courses, setCourses] = useState([]);
  const [filteredCourses, setFilteredCourses] = useState([]);

  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchCourses();
  }, []);

  async function fetchCourses() {
    try {
      setLoading(true);

      const res = await api.get("/courses");

      setCourses(res.data);
      setFilteredCourses(res.data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function onRefresh() {
    setRefreshing(true);
    fetchCourses();
  }

  function searchCourses(text) {
    setSearch(text);

    if (text.trim() === "") {
      setFilteredCourses(courses);
      return;
    }

    const result = courses.filter((course) => {
      return (
        course.title.toLowerCase().includes(text.toLowerCase()) ||
        course.category_name.toLowerCase().includes(text.toLowerCase()) ||
        course.instructor_name.toLowerCase().includes(text.toLowerCase())
      );
    });

    setFilteredCourses(result);
  }

  function renderItem({ item }) {
    return (
      <Card style={styles.card}>
        <Card.Content>
          <View style={styles.headerRow}>
            <View style={styles.iconBox}>
              <MaterialCommunityIcons
                name="book-open-page-variant"
                size={28}
                color="#fff"
              />
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.title}>{item.title}</Text>

              <Text style={styles.category}>{item.category_name}</Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <MaterialCommunityIcons
              name="account-tie"
              size={18}
              color="#2563EB"
            />

            <Text style={styles.info}>{item.instructor_name}</Text>
          </View>

          <View style={styles.infoRow}>
            <MaterialCommunityIcons
              name="currency-inr"
              size={18}
              color="#16A34A"
            />

            <Text style={styles.info}>₹ {item.price}</Text>
          </View>

          <Text numberOfLines={2} style={styles.description}>
            {item.description}
          </Text>

          <Button
            mode="contained"
            style={styles.button}
            onPress={() =>
              navigation.navigate("CourseDetails", {
                course: item,
              })
            }
          >
            View Details
          </Button>
        </Card.Content>
      </Card>
    );
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />

        <Text style={styles.loadingText}>Loading Courses...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <View style={styles.container}>
        <Searchbar
          placeholder="Search Courses..."
          value={search}
          onChangeText={searchCourses}
          style={styles.search}
        />

        <FlatList
          data={filteredCourses}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          contentContainerStyle={{
            paddingBottom: 20,
          }}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <MaterialCommunityIcons
                name="book-remove"
                size={60}
                color="#9CA3AF"
              />

              <Text style={styles.emptyTitle}>No Courses Found</Text>

              <Text style={styles.emptySubtitle}>
                Try another search keyword.
              </Text>
            </View>
          }
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F7FA",
  },

  container: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 10,
  },

  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F7FA",
  },

  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: "#6B7280",
  },

  search: {
    borderRadius: 14,
    marginBottom: 18,
  },

  card: {
    borderRadius: 18,
    marginBottom: 15,
    elevation: 3,
    backgroundColor: "#FFFFFF",
  },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  iconBox: {
    width: 55,
    height: 55,
    borderRadius: 15,
    backgroundColor: "#F59E0B",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },

  title: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },

  category: {
    marginTop: 3,
    color: "#6B7280",
    fontSize: 15,
  },

  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },

  info: {
    marginLeft: 8,
    color: "#374151",
    fontSize: 15,
  },

  description: {
    marginTop: 8,
    color: "#4B5563",
    lineHeight: 22,
  },

  button: {
    marginTop: 18,
    borderRadius: 12,
    backgroundColor: "#F59E0B",
    paddingVertical: 5,
  },

  emptyContainer: {
    marginTop: 80,
    alignItems: "center",
    justifyContent: "center",
  },

  emptyTitle: {
    marginTop: 15,
    fontSize: 20,
    fontWeight: "700",
    color: "#374151",
  },

  emptySubtitle: {
    marginTop: 6,
    color: "#9CA3AF",
    fontSize: 15,
  },
});
