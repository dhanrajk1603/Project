import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";

import { Avatar, TextInput, Button, Card } from "react-native-paper";

import { MaterialCommunityIcons } from "@expo/vector-icons";

import api from "../api/api";
import COLORS from "../constants/colors";
import { getToken, logoutStorage } from "../utils/storage";

export default function ProfileScreen({ navigation }) {
  const [loading, setLoading] = useState(false);

  const [profile, setProfile] = useState({
    name: "",
    email: "",
    mobile: "",
  });

  const [stats, setStats] = useState({
    skills: 0,
    jobs: 0,
    courses: 0,
  });

  useEffect(() => {
    loadProfile();
  }, []);

  async function loadProfile() {
    try {
      setLoading(true);

      const token = await getToken();

      const headers = {
        Authorization: `Bearer ${token}`,
      };

      const [profileRes, skillsRes, jobsRes, coursesRes] = await Promise.all([
        api.get("/users/profile", { headers }),
        api.get("/skills/my-skills", { headers }),
        api.get("/recommendations/jobs", { headers }),
        api.get("/recommendations/courses", { headers }),
      ]);

      setProfile(profileRes.data);

      setStats({
        skills: skillsRes.data.length,
        jobs: jobsRes.data.length,
        courses: coursesRes.data.length,
      });
    } catch (error) {
      console.log("LOAD PROFILE ERROR");
      console.log(error);
    } finally {
      setLoading(false);
    }
  }

  async function updateProfile() {
    try {
      const token = await getToken();

      console.log("PROFILE DATA =>", profile);

      const response = await api.put(
        "/users/profile",
        {
          name: profile.name,
          mobile: profile.mobile,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      console.log("UPDATE RESPONSE =>", response.data);

      Alert.alert("Success", "Profile Updated Successfully");

      await loadProfile();
    } catch (error) {
      console.log("UPDATE ERROR =>");
      console.log(error);
      console.log(error.response?.data);

      Alert.alert(
        "Update Error",
        JSON.stringify(error.response?.data || error.message),
      );
    }
  }

  function logout() {
    Alert.alert("Logout", "Are you sure you want to logout?", [
      {
        text: "Cancel",
        style: "cancel",
      },
      {
        text: "Logout",
        style: "destructive",
        onPress: async () => {
          await logoutStorage();
          navigation.replace("Login");
        },
      },
    ]);
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />

        <Text style={styles.loadingText}>Loading Profile...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <Card style={styles.profileCard}>
          <Card.Content style={styles.profileContent}>
            <Avatar.Text
              size={95}
              style={styles.avatar}
              label={
                profile.name
                  ? profile.name
                      .split(" ")
                      .map((word) => word[0])
                      .join("")
                      .substring(0, 2)
                      .toUpperCase()
                  : "U"
              }
            />

            <Text style={styles.name}>{profile.name || "User"}</Text>

            <Text style={styles.email}>{profile.email}</Text>
          </Card.Content>
        </Card>

        <View style={styles.statsRow}>
          <Card style={styles.statCard}>
            <Card.Content>
              <MaterialCommunityIcons name="brain" size={28} color="#2563EB" />

              <Text style={styles.statValue}>{stats.skills}</Text>

              <Text style={styles.statTitle}>Skills</Text>
            </Card.Content>
          </Card>

          <Card style={styles.statCard}>
            <Card.Content>
              <MaterialCommunityIcons
                name="briefcase"
                size={28}
                color="#16A34A"
              />

              <Text style={styles.statValue}>{stats.jobs}</Text>

              <Text style={styles.statTitle}>Jobs</Text>
            </Card.Content>
          </Card>

          <Card style={styles.statCard}>
            <Card.Content>
              <MaterialCommunityIcons
                name="book-open-page-variant"
                size={28}
                color="#F59E0B"
              />

              <Text style={styles.statValue}>{stats.courses}</Text>

              <Text style={styles.statTitle}>Courses</Text>
            </Card.Content>
          </Card>
        </View>

        <Text style={styles.sectionTitle}>Personal Information</Text>

        <Card style={styles.infoCard}>
          <Card.Content>
            <TextInput
              label="Full Name"
              mode="outlined"
              value={profile.name}
              onChangeText={(text) =>
                setProfile({
                  ...profile,
                  name: text,
                })
              }
              style={styles.input}
            />

            <TextInput
              label="Email"
              mode="outlined"
              value={profile.email}
              editable={false}
              style={styles.input}
            />

            <TextInput
              label="Mobile Number"
              mode="outlined"
              value={profile.mobile}
              onChangeText={(text) =>
                setProfile({
                  ...profile,
                  mobile: text,
                })
              }
              style={styles.input}
            />

            <Button
              mode="contained"
              style={styles.updateButton}
              onPress={updateProfile}
            >
              Update Profile
            </Button>
          </Card.Content>
        </Card>

        <Card style={styles.actionCard}>
          <Card.Content>
            <TouchableOpacity
              style={styles.actionRow}
              onPress={() => navigation.navigate("MyCourses")}
            >
              <MaterialCommunityIcons
                name="book-open-page-variant"
                size={26}
                color="#16A34A"
              />

              <Text style={styles.actionText}>My Courses</Text>

              <MaterialCommunityIcons
                name="chevron-right"
                size={24}
                color="#9CA3AF"
              />
            </TouchableOpacity>
          </Card.Content>
        </Card>

        <Card style={styles.actionCard}>
          <Card.Content>
            <TouchableOpacity
              style={styles.actionRow}
              onPress={() => navigation.navigate("MyAppliedJobs")}
            >
              <MaterialCommunityIcons
                name="briefcase-check"
                size={26}
                color="#2563EB"
              />

              <Text style={styles.actionText}>My Applied Jobs</Text>

              <MaterialCommunityIcons
                name="chevron-right"
                size={24}
                color="#9CA3AF"
              />
            </TouchableOpacity>
          </Card.Content>
        </Card>

        <Button
          mode="contained"
          buttonColor="#EF4444"
          style={styles.logoutButton}
          onPress={logout}
        >
          Logout
        </Button>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F7FA",
  },

  container: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 10,
  },

  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F7FA",
  },

  loadingText: {
    marginTop: 10,
    color: "#6B7280",
    fontSize: 16,
  },

  profileCard: {
    borderRadius: 20,
    elevation: 4,
    marginBottom: 20,
    backgroundColor: "#FFFFFF",
  },

  profileContent: {
    alignItems: "center",
    paddingVertical: 25,
  },

  avatar: {
    backgroundColor: "#2563EB",
    marginBottom: 15,
  },

  name: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#111827",
  },

  email: {
    marginTop: 5,
    color: "#6B7280",
    fontSize: 15,
  },

  statsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },

  statCard: {
    width: "31%",
    borderRadius: 15,
    elevation: 3,
    backgroundColor: "#FFFFFF",
  },

  statValue: {
    fontSize: 24,
    fontWeight: "bold",
    marginTop: 10,
    color: "#111827",
    textAlign: "center",
  },

  statTitle: {
    marginTop: 5,
    color: "#6B7280",
    textAlign: "center",
  },

  sectionTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 15,
  },

  infoCard: {
    borderRadius: 18,
    elevation: 3,
    backgroundColor: "#FFFFFF",
    marginBottom: 20,
  },

  input: {
    marginBottom: 15,
    backgroundColor: "#FFFFFF",
  },

  updateButton: {
    marginTop: 5,
    borderRadius: 12,
    backgroundColor: "#2563EB",
    paddingVertical: 5,
  },

  actionCard: {
    borderRadius: 18,
    elevation: 3,
    backgroundColor: "#FFFFFF",
    marginBottom: 20,
  },

  actionRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  actionText: {
    flex: 1,
    marginLeft: 15,
    fontSize: 17,
    color: "#111827",
    fontWeight: "600",
  },

  logoutButton: {
    borderRadius: 12,
    paddingVertical: 6,
    marginBottom: 35,
  },
});
