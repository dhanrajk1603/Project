import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";
import * as WebBrowser from "expo-web-browser";

import { SafeAreaView } from "react-native-safe-area-context";
import { Platform } from "react-native";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import { Button, Card } from "react-native-paper";

import api from "../api/api";
import COLORS from "../constants/colors";
import { getToken } from "../utils/storage";

export default function CourseDetailsScreen({ route, navigation }) {
  const { course } = route.params;

  const [loading, setLoading] = useState(false);

  async function enrollCourse() {
    try {
      setLoading(true);

      const token = await getToken();
      if (!token) {
        navigation.navigate("Login", {
          sessionMessage: "Please log in before purchasing a course.",
        });
        return;
      }

      const order = await api.post(
        `/courses/${course.id}/order`,
        {},
        { headers: { Authorization: `Bearer ${token}` } },
      );

      // Debug: show platform and checkout URL
      console.log('Platform:', Platform.OS, 'Checkout URL:', order?.data?.checkout_url);

      // Web redirect – double‑check environment
      const isWeb = Platform.OS === "web" || (typeof window !== "undefined" && !!window.location);
      if (isWeb && order?.data?.checkout_url) {
        // Using assign ensures the current tab navigates (avoids popup blockers)
        window.location.assign(order.data.checkout_url);
        return; // Skip native flow
      }

      // Native flow – open in an in‑app browser session
      const result = await WebBrowser.openAuthSessionAsync(
        order.data.checkout_url,
        "careerrecommendation://payment-result",
      );

      // Verify payment status from backend
      try {
        const historyRes = await api.get("/payments/history", {
          headers: { Authorization: `Bearer ${token}` },
        });
        const isPaid = Array.isArray(historyRes.data) && historyRes.data.some(
          (p) => p.course_id === course.id && p.status === "paid",
        );
        if (isPaid) {
          Alert.alert("Payment successful", "You are now enrolled in this course.");
          navigation.navigate("MyCourses");
          return;
        }
      } catch (e) {}

      if (result.type === "success" && result.url.includes("status=success")) {
        Alert.alert("Payment successful", "You are now enrolled in this course.");
        navigation.navigate("MyCourses");
      } else if (result.type !== "cancel" && result.type !== "dismiss") {
        Alert.alert("Payment not completed", "Your payment was cancelled or could not be verified.");
      }
    } catch (error) {
      Alert.alert(
        "Enrollment",
        error.response?.data?.message || "Unable to enroll.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={26} color="#111827" />
        </TouchableOpacity>

        <View style={styles.header}>
          <View style={styles.iconBox}>
            <MaterialCommunityIcons
              name="book-open-page-variant"
              size={45}
              color="#fff"
            />
          </View>

          <Text style={styles.title}>{course.title}</Text>

          <Text style={styles.category}>{course.category_name}</Text>
        </View>

        <Card style={styles.infoCard}>
          <Card.Content>
            <View style={styles.row}>
              <MaterialCommunityIcons
                name="account-tie"
                size={22}
                color="#2563EB"
              />

              <Text style={styles.infoText}>{course.instructor_name}</Text>
            </View>

            <View style={styles.row}>
              <MaterialCommunityIcons
                name="currency-inr"
                size={22}
                color="#16A34A"
              />

              <Text style={styles.infoText}>₹ {course.price}</Text>
            </View>
          </Card.Content>
        </Card>

        <Text style={styles.heading}>Description</Text>

        <Card style={styles.descriptionCard}>
          <Card.Content>
            <Text style={styles.description}>{course.description}</Text>
          </Card.Content>
        </Card>

        <Text style={styles.heading}>What You Will Learn</Text>

        <View style={styles.skillContainer}>
          <View style={styles.skillChip}>
            <Text style={styles.skillText}>Practical Projects</Text>
          </View>

          <View style={styles.skillChip}>
            <Text style={styles.skillText}>Real World Examples</Text>
          </View>

          <View style={styles.skillChip}>
            <Text style={styles.skillText}>Certificate</Text>
          </View>

          <View style={styles.skillChip}>
            <Text style={styles.skillText}>Lifetime Access</Text>
          </View>
        </View>

        <Button
          mode="contained"
          style={styles.enrollButton}
          loading={loading}
          onPress={enrollCourse}
        >
          Buy Now
        </Button>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F7FA",
  },

  container: {
    flex: 1,
    padding: 20,
  },

  backButton: {
    width: 45,
    height: 45,
    borderRadius: 12,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    elevation: 3,
    marginBottom: 20,
  },

  header: {
    alignItems: "center",
    marginBottom: 25,
  },

  iconBox: {
    width: 90,
    height: 90,
    borderRadius: 20,
    backgroundColor: "#F59E0B",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15,
  },

  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#111827",
    textAlign: "center",
  },

  category: {
    marginTop: 6,
    fontSize: 16,
    color: "#6B7280",
  },

  infoCard: {
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    elevation: 3,
    marginBottom: 20,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },

  infoText: {
    marginLeft: 12,
    fontSize: 16,
    color: "#374151",
  },

  heading: {
    fontSize: 21,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 12,
    marginTop: 10,
  },

  descriptionCard: {
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    elevation: 3,
    marginBottom: 20,
  },

  description: {
    fontSize: 16,
    lineHeight: 24,
    color: "#4B5563",
  },

  skillContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 25,
  },

  skillChip: {
    backgroundColor: "#FEF3C7",
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 10,
    marginBottom: 10,
  },

  skillText: {
    color: "#B45309",
    fontWeight: "600",
  },

  enrollButton: {
    backgroundColor: "#16A34A",
    borderRadius: 14,
    paddingVertical: 8,
    marginBottom: 35,
  },
});
