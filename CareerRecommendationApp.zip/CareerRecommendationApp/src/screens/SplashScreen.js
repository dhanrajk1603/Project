import React, { useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
} from "react-native";

import COLORS from "../constants/colors";
import api from "../api/api";
import { getToken, logoutStorage } from "../utils/storage";

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    checkLogin();
  }, []);

  const checkLogin = async () => {
    try {
      const token = await getToken();
      if (!token) {
        setTimeout(() => navigation.replace("Login"), 1200);
        return;
      }

      // Do not send a user to a broken dashboard when their saved token has
      // expired or belongs to a different API environment.
      await api.get("/users/profile", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setTimeout(() => navigation.replace("Dashboard"), 700);
    } catch (error) {
      await logoutStorage();
      navigation.replace("Login", {
        sessionMessage: "Your previous session has expired. Please sign in again.",
      });
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Career Recommendation
      </Text>

      <Text style={styles.subtitle}>
        Find Your Dream Career
      </Text>

      <ActivityIndicator
        size="large"
        color={COLORS.primary}
        style={{ marginTop: 30 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: "center",
    alignItems: "center",
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: COLORS.primary,
  },

  subtitle: {
    fontSize: 16,
    color: COLORS.text,
    marginTop: 10,
  },
});
