import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
} from "react-native";

import { Card } from "react-native-paper";

import api from "../api/api";
import COLORS from "../constants/colors";
import { getToken } from "../utils/storage";

export default function RecommendationsScreen() {
  const [jobs, setJobs] = useState([]);
  const [courses, setCourses] = useState([]);

  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadRecommendations();
  }, []);

  const loadRecommendations = async () => {
    try {
      const token = await getToken();

      const headers = {
        Authorization: `Bearer ${token}`,
      };

      const [jobRes, courseRes] = await Promise.all([
        api.get("/recommendations/jobs", { headers }),
        api.get("/recommendations/courses", { headers }),
      ]);

      setJobs(jobRes.data);
      setCourses(courseRes.data);
    } catch (error) {
      console.log(error);
    } finally {
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadRecommendations();
  };

  return (
    <ScrollView
      style={styles.container}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }
    >
      <Text style={styles.heading}>Recommended Jobs</Text>

      {jobs.length === 0 ? (
        <Text style={styles.empty}>No Job Recommendation Found</Text>
      ) : (
        jobs.map((item) => (
          <Card key={item.id} style={styles.card}>
            <Card.Content>
              <Text style={styles.title}>{item.title}</Text>

              <Text>{item.company}</Text>

              <Text>📍 {item.location}</Text>

              <Text>💰 {item.salary}</Text>

              <Text>Match : {item.match_percentage}%</Text>
              <Text style={styles.aiText}>{item.ai?.explanation}</Text>
              <Text style={styles.aiText}>Next: {item.ai?.learningSuggestion}</Text>
            </Card.Content>
          </Card>
        ))
      )}

      <Text style={styles.heading}>Recommended Courses</Text>

      {courses.length === 0 ? (
        <Text style={styles.empty}>No Course Recommendation Found</Text>
      ) : (
        courses.map((item) => (
          <Card key={item.id} style={styles.card}>
            <Card.Content>
              <Text style={styles.title}>{item.title}</Text>
              <Text>{item.category_name}</Text>
              <Text>👨‍🏫 {item.instructor_name}</Text>
              <Text>₹ {item.price}</Text>{" "}
              <Text>Match : {item.match_percentage || 100}%</Text>
              <Text style={styles.aiText}>{item.ai?.reason}</Text>
              <Text style={styles.aiText}>Next: {item.ai?.nextLearningSuggestion}</Text>
            </Card.Content>
          </Card>
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    padding: 15,
  },

  heading: {
    fontSize: 22,
    fontWeight: "bold",
    color: COLORS.primary,
    marginTop: 20,
    marginBottom: 10,
  },

  card: {
    marginBottom: 15,
    borderRadius: 15,
    elevation: 4,
    backgroundColor: "#FFFFFF",
  },

  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: COLORS.primary,
    marginBottom: 5,
  },

  empty: {
    textAlign: "center",
    color: "#888",
    fontSize: 16,
    marginVertical: 20,
  },
  aiText: { marginTop: 7, color: "#475569", lineHeight: 20 },
});
