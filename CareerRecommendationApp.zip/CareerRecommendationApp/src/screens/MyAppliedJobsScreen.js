import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  ActivityIndicator,
} from "react-native";

import { Searchbar, Card } from "react-native-paper";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import api from "../api/api";
import COLORS from "../constants/colors";
import { getToken } from "../utils/storage";

export default function MyAppliedJobsScreen() {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);

  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadJobs();
  }, []);

  async function loadJobs() {
    try {
      setLoading(true);

      const token = await getToken();

      const res = await api.get("/job-applications/my-applications", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setJobs(res.data);
      setFilteredJobs(res.data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }

  function onRefresh() {
    setRefreshing(true);
    loadJobs();
  }

  function searchJob(text) {
    setSearch(text);

    if (text.trim() === "") {
      setFilteredJobs(jobs);
      return;
    }

    const result = jobs.filter(
      (job) =>
        job.title.toLowerCase().includes(text.toLowerCase()) ||
        job.company.toLowerCase().includes(text.toLowerCase()) ||
        job.location.toLowerCase().includes(text.toLowerCase())
    );

    setFilteredJobs(result);
  }

  function renderItem({ item }) {
    return (
      <Card style={styles.card}>
        <Card.Content>
          <View style={styles.headerRow}>
            <View style={styles.iconBox}>
              <MaterialCommunityIcons
                name="briefcase-check"
                size={28}
                color="#fff"
              />
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.title}>{item.title}</Text>

              <Text style={styles.company}>{item.company}</Text>
            </View>
          </View>

          <View style={styles.infoRow}>
            <MaterialCommunityIcons
              name="map-marker"
              size={18}
              color="#2563EB"
            />

            <Text style={styles.info}>{item.location}</Text>
          </View>

          <View style={styles.infoRow}>
            <MaterialCommunityIcons
              name="currency-inr"
              size={18}
              color="#16A34A"
            />

            <Text style={styles.info}>{item.salary}</Text>
          </View>

          <View style={styles.statusContainer}>
            <Text style={styles.statusLabel}>Status</Text>

            <Text style={styles.status}>{item.status}</Text>
          </View>
        </Card.Content>
      </Card>
    );
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.loader}>
        <ActivityIndicator size="large" color={COLORS.primary} />

        <Text style={styles.loadingText}>Loading Applied Jobs...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <View style={styles.container}>
        <Searchbar
          placeholder="Search Applied Jobs..."
          value={search}
          onChangeText={searchJob}
          style={styles.search}
        />

        <FlatList
          data={filteredJobs}
          renderItem={renderItem}
          keyExtractor={(item) => item.id.toString()}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          contentContainerStyle={{
            paddingBottom: 20,
          }}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <MaterialCommunityIcons
                name="briefcase-remove"
                size={60}
                color="#9CA3AF"
              />

              <Text style={styles.emptyTitle}>No Applied Jobs</Text>

              <Text style={styles.emptySubtitle}>
                Apply for jobs to see them here.
              </Text>
            </View>
          }
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F7FA",
  },

  container: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 10,
  },

  loader: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#F5F7FA",
  },

  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#6B7280",
  },

  search: {
    marginBottom: 18,
    borderRadius: 14,
  },

  card: {
    borderRadius: 18,
    marginBottom: 15,
    backgroundColor: "#FFFFFF",
    elevation: 3,
  },

  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },

  iconBox: {
    width: 55,
    height: 55,
    borderRadius: 15,
    backgroundColor: "#2563EB",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 15,
  },

  title: {
    fontSize: 18,
    fontWeight: "700",
    color: "#111827",
  },

  company: {
    marginTop: 4,
    color: "#6B7280",
    fontSize: 15,
  },

  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },

  info: {
    marginLeft: 8,
    color: "#374151",
    fontSize: 15,
  },

  statusContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
  },

  statusLabel: {
    fontWeight: "700",
    marginRight: 10,
    color: "#111827",
  },

  status: {
    color: "#16A34A",
    fontWeight: "700",
    fontSize: 15,
  },

  emptyContainer: {
    marginTop: 80,
    alignItems: "center",
  },

  emptyTitle: {
    marginTop: 15,
    fontSize: 20,
    fontWeight: "700",
    color: "#374151",
  },

  emptySubtitle: {
    marginTop: 6,
    textAlign: "center",
    color: "#9CA3AF",
    fontSize: 15,
  },
});