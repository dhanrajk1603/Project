import React, { useEffect, useState, useContext } from "react";
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from "react-native";

import { TextInput, Button, Card } from "react-native-paper";
import Toast from "react-native-toast-message";

import api from "../api/api";
import COLORS from "../constants/colors";
import { saveToken, saveUser } from "../utils/storage";
import { AuthContext } from "../context/AuthContext";

export default function LoginScreen({ navigation, route }) {
  const { setUser } = useContext(AuthContext);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState(route.params?.sessionMessage || "");

  useEffect(() => {
    setErrorMessage(route.params?.sessionMessage || "");
  }, [route.params?.sessionMessage]);

  const login = async () => {
    if (!email || !password) {
      setErrorMessage("Enter both your email address and password.");
      Toast.show({
        type: "error",
        text1: "Please enter email and password",
      });
      return;
    }

    try {
      setLoading(true);
      setErrorMessage("");

      const res = await api.post("/auth/login", {
        email,
        password,
      });

      await saveToken(res.data.token);
      await saveUser(res.data.user);

      setUser(res.data.user);

      Toast.show({
        type: "success",
        text1: "Login Successful",
      });

      navigation.replace("Dashboard");
    } catch (error) {
      const message = error.response?.data?.message ||
        (error.code === "ECONNABORTED"
          ? "The server took too long to respond. Please try again."
          : "Unable to reach the server. Check your internet connection and try again.");
      setErrorMessage(message);
      Toast.show({
        type: "error",
        text1: "Login failed",
        text2: message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <Card style={styles.card}>
        <Card.Content>
          <Text style={styles.title}>Career Recommendation</Text>

          <Text style={styles.subtitle}>Login to continue</Text>

          <TextInput
            label="Email"
            mode="outlined"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
            style={styles.input}
          />

          <TextInput
            label="Password"
            mode="outlined"
            secureTextEntry
            value={password}
            onChangeText={setPassword}
            style={styles.input}
            autoComplete="password"
          />

          {errorMessage ? <View style={styles.errorBox}><Text style={styles.errorText}>{errorMessage}</Text></View> : null}

          <Button
            mode="contained"
            loading={loading}
            disabled={loading}
            onPress={login}
            style={styles.button}
          >
            Login
          </Button>

          <TouchableOpacity onPress={() => navigation.navigate("Register")}>
            <Text style={styles.footer}>
              Don't have an account? Create Account
            </Text>
          </TouchableOpacity>

          <Text
            style={{
              textAlign: "center",
              color: "#666",
              marginTop: 15,
            }}
          >
            Welcome to Career Recommendation System
          </Text>
        </Card.Content>
      </Card>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: "center",
    padding: 20,
  },

  card: {
    borderRadius: 20,
    elevation: 5,
    paddingVertical: 20,
  },

  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    color: COLORS.primary,
    marginBottom: 5,
  },

  subtitle: {
    textAlign: "center",
    color: COLORS.text,
    marginBottom: 25,
    fontSize: 16,
  },

  input: {
    marginBottom: 15,
  },

  errorBox: {
    backgroundColor: "#FEF2F2",
    borderColor: "#FECACA",
    borderWidth: 1,
    borderRadius: 10,
    padding: 12,
    marginBottom: 4,
  },

  errorText: {
    color: "#B91C1C",
    fontSize: 13,
    lineHeight: 19,
  },

  button: {
    marginTop: 10,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: COLORS.primary,
  },

  footer: {
    marginTop: 20,
    textAlign: "center",
    color: COLORS.text,
  },
});
