import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from "react-native";

import { SafeAreaView } from "react-native-safe-area-context";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import { Button } from "react-native-paper";
import * as DocumentPicker from "expo-document-picker";

import api from "../api/api";
import COLORS from "../constants/colors";
import { getToken } from "../utils/storage";

export default function JobDetailsScreen({ route, navigation }) {
  const { job, applied = false } = route.params;

  const [loading, setLoading] = useState(false);

  async function applyJob() {
    if (applied) {
      Alert.alert("Already Applied", "You have already applied for this job.");
      return;
    }

    try {
      setLoading(true);

      const token = await getToken();

      const result = await DocumentPicker.getDocumentAsync({
        type: [
          "application/pdf",
          "application/msword",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ],
        multiple: false,
        copyToCacheDirectory: true,
      });

      if (result.canceled) {
        return;
      }

      const resume = result.assets[0];

      const formData = new FormData();

      formData.append("job_id", String(job.id));

      formData.append("resume", {
        uri: resume.uri,
        name: resume.name,
        type: resume.mimeType || "application/pdf",
      });

      await api.post("/job-applications/apply", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      Alert.alert("Success", "Job application submitted successfully.", [
        {
          text: "OK",
          onPress: () => navigation.goBack(),
        },
      ]);
    } catch (error) {
      console.log("Apply Job Error:", error);

      Alert.alert(
        "Application",
        error.response?.data?.message || "Unable to apply.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={["top"]}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={26} color="#111827" />
        </TouchableOpacity>

        <View style={styles.header}>
          <View style={styles.iconBox}>
            <MaterialCommunityIcons name="briefcase" size={45} color="#fff" />
          </View>

          <Text style={styles.title}>{job.title}</Text>

          <Text style={styles.company}>{job.company}</Text>
        </View>

        <View style={styles.infoCard}>
          <View style={styles.row}>
            <MaterialCommunityIcons
              name="map-marker"
              size={24}
              color="#2563EB"
            />

            <Text style={styles.infoText}>{job.location}</Text>
          </View>

          <View style={styles.row}>
            <MaterialCommunityIcons
              name="currency-inr"
              size={24}
              color="#16A34A"
            />

            <Text style={styles.infoText}>{job.salary}</Text>
          </View>
        </View>

        <Text style={styles.heading}>Description</Text>

        <View style={styles.descriptionCard}>
          <Text style={styles.description}>
            {job.description || "No description available."}
          </Text>
        </View>

        <Text style={styles.heading}>Required Skills</Text>

        <View style={styles.skillContainer}>
          <View style={styles.skillChip}>
            <Text style={styles.skillText}>React Native</Text>
          </View>

          <View style={styles.skillChip}>
            <Text style={styles.skillText}>JavaScript</Text>
          </View>

          <View style={styles.skillChip}>
            <Text style={styles.skillText}>REST API</Text>
          </View>

          <View style={styles.skillChip}>
            <Text style={styles.skillText}>Git</Text>
          </View>
        </View>

        {applied ? (
          <Button
            mode="contained"
            disabled
            style={[
              styles.applyButton,
              {
                backgroundColor: "#9CA3AF",
              },
            ]}
          >
            Already Applied
          </Button>
        ) : (
          <Button
            mode="contained"
            style={styles.applyButton}
            loading={loading}
            disabled={loading}
            onPress={applyJob}
          >
            Apply Now
          </Button>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F5F7FA",
  },

  container: {
    flex: 1,
    padding: 20,
  },

  backButton: {
    width: 45,
    height: 45,
    borderRadius: 12,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    elevation: 3,
    marginBottom: 20,
  },

  header: {
    alignItems: "center",
    marginBottom: 25,
  },

  iconBox: {
    width: 90,
    height: 90,
    borderRadius: 20,
    backgroundColor: "#2563EB",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 15,
  },

  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#111827",
    textAlign: "center",
  },

  company: {
    marginTop: 6,
    fontSize: 16,
    color: "#6B7280",
  },

  infoCard: {
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    elevation: 3,
    padding: 20,
    marginBottom: 20,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },

  infoText: {
    marginLeft: 12,
    fontSize: 16,
    color: "#374151",
  },

  heading: {
    fontSize: 21,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 12,
    marginTop: 10,
  },

  descriptionCard: {
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    elevation: 3,
    padding: 20,
    marginBottom: 20,
  },

  description: {
    fontSize: 16,
    lineHeight: 24,
    color: "#4B5563",
  },

  skillContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 25,
  },

  skillChip: {
    backgroundColor: "#DBEAFE",
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 10,
    marginBottom: 10,
  },

  skillText: {
    color: "#1D4ED8",
    fontWeight: "600",
  },

  applyButton: {
    backgroundColor: "#2563EB",
    borderRadius: 14,
    paddingVertical: 8,
    marginBottom: 35,
  },
});
