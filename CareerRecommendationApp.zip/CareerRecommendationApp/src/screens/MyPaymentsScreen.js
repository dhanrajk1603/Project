import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Card } from "react-native-paper";
import api from "../api/api";
import { getToken } from "../utils/storage";
import COLORS from "../constants/colors";
export default function MyPaymentsScreen() {
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      try {
        const token = await getToken();
        const response = await api.get("/payments/history", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setPayments(response.data);
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  if (loading)
    return (
      <View style={styles.loader}>
        <ActivityIndicator color={COLORS.primary} size="large" />
      </View>
    );
  return (
    <SafeAreaView style={styles.safe}>
      <FlatList
        contentContainerStyle={styles.list}
        data={payments}
        keyExtractor={(item) => String(item.payment_id)}
        ListEmptyComponent={<Text style={styles.empty}>No payments yet.</Text>}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <Card.Content>
              <Text style={styles.title}>{item.course_title}</Text>
              <Text>Amount: ₹ {item.amount}</Text>
              <Text>Status: {item.status}</Text>
              <Text>
                Transaction:{" "}
                {item.razorpay_payment_id || item.razorpay_order_id}
              </Text>
              <Text>{new Date(item.created_at).toLocaleDateString()}</Text>
            </Card.Content>
          </Card>
        )}
      />
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F7FA" },
  loader: { flex: 1, alignItems: "center", justifyContent: "center" },
  list: { padding: 16 },
  card: { marginBottom: 12, borderRadius: 15 },
  title: { fontSize: 17, fontWeight: "700", marginBottom: 7 },
  empty: { textAlign: "center", marginTop: 60, color: "#64748B" },
});
