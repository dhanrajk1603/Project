import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { MaterialCommunityIcons } from "@expo/vector-icons";

import DashboardScreen from "../screens/DashboardScreen";
import JobsScreen from "../screens/JobsScreen";
import CoursesScreen from "../screens/CoursesScreen";
import ProfileScreen from "../screens/ProfileScreen";

import COLORS from "../constants/colors";

const Tab = createBottomTabNavigator();

export default function BottomNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,

        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: "gray",

        tabBarStyle: {
          height: 65,
          paddingBottom: 8,
          paddingTop: 8,
        },

        tabBarIcon: ({ color, size }) => {
          let iconName = "";

          switch (route.name) {
            case "Dashboard":
              iconName = "view-dashboard";
              break;

            case "Jobs":
              iconName = "briefcase";
              break;

            case "Courses":
              iconName = "book-open-page-variant";
              break;

            case "Profile":
              iconName = "account-circle";
              break;
          }

          return (
            <MaterialCommunityIcons
              name={iconName}
              size={size}
              color={color}
            />
          );
        },
      })}
    >
      <Tab.Screen
        name="Dashboard"
        component={DashboardScreen}
      />

      <Tab.Screen
        name="Jobs"
        component={JobsScreen}
      />

      <Tab.Screen
        name="Courses"
        component={CoursesScreen}
      />

      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
      />
    </Tab.Navigator>
  );
}