import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import SplashScreen from "../screens/SplashScreen";
import LoginScreen from "../screens/LoginScreen";
import BottomNavigator from "./BottomNavigator";
import MySkillsScreen from "../screens/MySkillsScreen";
import JobDetailsScreen from "../screens/JobDetailsScreen";
import CourseDetailsScreen from "../screens/CourseDetailsScreen";
import MyCoursesScreen from "../screens/MyCoursesScreen";
import MyAppliedJobsScreen from "../screens/MyAppliedJobsScreen";
import RegisterScreen from "../screens/RegisterScreen";
import AICareerScreen from "../screens/AICareerScreen";
import MyPaymentsScreen from "../screens/MyPaymentsScreen";

const Stack = createNativeStackNavigator();

const linking = {
  prefixes: [
    "careerrecommendation://",
    "http://localhost:8081",
    "http://localhost:8082",
    "http://localhost:8085",
  ],
  config: {
    screens: {
      Splash: "splash",
      Login: "login",
      Register: "register",
      Dashboard: "dashboard",
      MyCourses: "payment-result",
      MyPayments: "my-payments",
      CourseDetails: "course-details",
    },
  },
};

export default function AppNavigator() {
  return (
    <NavigationContainer linking={linking}>
      <Stack.Navigator
        initialRouteName="Splash"
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen name="MySkills" component={MySkillsScreen} />
        <Stack.Screen name="JobDetails" component={JobDetailsScreen} />
        <Stack.Screen name="CourseDetails" component={CourseDetailsScreen} />
        <Stack.Screen name="MyCourses" component={MyCoursesScreen} />
        <Stack.Screen name="MyAppliedJobs" component={MyAppliedJobsScreen} />
        <Stack.Screen name="AICareer" component={AICareerScreen} />
        <Stack.Screen name="MyPayments" component={MyPaymentsScreen} />
        <Stack.Screen name="Dashboard" component={BottomNavigator} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
