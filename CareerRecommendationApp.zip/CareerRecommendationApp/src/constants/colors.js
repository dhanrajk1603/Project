const COLORS = {
  primary: "#2563EB",
  secondary: "#1E40AF",
  background: "#F5F7FA",
  white: "#FFFFFF",
  black: "#1F2937",
  text: "#374151",
  border: "#D1D5DB",
  success: "#16A34A",
  danger: "#DC2626",
  warning: "#F59E0B",
  card: "#FFFFFF",
  placeholder: "#9CA3AF",
};

export default COLORS;