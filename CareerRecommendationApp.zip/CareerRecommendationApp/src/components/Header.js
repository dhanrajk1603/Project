import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Avatar } from "react-native-paper";
import COLORS from "../constants/colors";

export default function Header({ user }) {
  const currentHour = new Date().getHours();

  let greeting = "Good Evening";

  if (currentHour < 12) {
    greeting = "Good Morning";
  } else if (currentHour < 17) {
    greeting = "Good Afternoon";
  }

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.greeting}>
          {greeting} 👋
        </Text>

        <Text style={styles.name}>
          {user?.name || "User"}
        </Text>
      </View>

      <Avatar.Text
        size={55}
        label={
          user?.name
            ? user.name
                .split(" ")
                .map((word) => word[0])
                .join("")
                .substring(0, 2)
                .toUpperCase()
            : "U"
        }
        style={styles.avatar}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 10,
    marginBottom: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  greeting: {
    fontSize: 18,
    color: "#6B7280",
  },

  name: {
    fontSize: 26,
    fontWeight: "bold",
    color: COLORS.black,
    marginTop: 5,
  },

  avatar: {
    backgroundColor: COLORS.primary,
  },
});