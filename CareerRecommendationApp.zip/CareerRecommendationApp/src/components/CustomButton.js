import React from "react";
import { StyleSheet } from "react-native";
import { Button } from "react-native-paper";
import COLORS from "../constants/colors";

export default function CustomButton({
  title,
  onPress,
  loading = false,
  mode = "contained",
}) {
  return (
    <Button
      mode={mode}
      loading={loading}
      onPress={onPress}
      style={styles.button}
      contentStyle={styles.content}
      labelStyle={styles.label}
    >
      {title}
    </Button>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 10,
    marginTop: 10,
    backgroundColor: COLORS.primary,
  },

  content: {
    height: 50,
  },

  label: {
    fontSize: 16,
    color: "#FFFFFF",
    fontWeight: "bold",
  },
});