import React from "react";
import { StyleSheet } from "react-native";
import { Card, Text } from "react-native-paper";
import COLORS from "../constants/colors";

export default function CustomCard({
  title,
  value,
  color = COLORS.primary,
}) {
  return (
    <Card
      style={[
        styles.card,
        {
          borderLeftColor: color,
        },
      ]}
    >
      <Card.Content>
        <Text style={styles.title}>
          {title}
        </Text>

        <Text
          style={[
            styles.value,
            {
              color,
            },
          ]}
        >
          {value}
        </Text>
      </Card.Content>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    margin: 8,
    borderRadius: 18,
    borderLeftWidth: 6,
    elevation: 4,
    backgroundColor: "#FFFFFF",
  },

  title: {
    fontSize: 15,
    color: "#6B7280",
  },

  value: {
    marginTop: 12,
    fontSize: 30,
    fontWeight: "bold",
  },
});