const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const path = require("path");

const rateLimit = require("express-rate-limit");

const swaggerUi = require("swagger-ui-express");

const swaggerSpec = require("./docs/swagger");

const routes = require("./routes");

const errorHandler = require("./middleware/error.middleware");

const app = express();

app.set("trust proxy", 1);

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,

  // The app dashboard makes several concurrent API calls. Keep a strict
  // production default while avoiding a false "Too many requests" lockout
  // during local web/mobile testing.
  max: Number(
    process.env.RATE_LIMIT_MAX ||
      (process.env.NODE_ENV === "production" ? 300 : 1000),
  ),

  // Browser CORS checks are not API calls. Counting them can make a normal
  // login appear unavailable after a few page reloads in development.
  skip: (req) => req.method === "OPTIONS",

  message: {
    success: false,
    message: "Too many requests, try again later.",
  },
});

// The payment checkout is rendered by this API and loads Razorpay's hosted
// checkout script. Keep the rest of Helmet's defaults while explicitly
// allowing the payment provider and the small inline bootstrap script.
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "https://checkout.razorpay.com"],
        connectSrc: ["'self'", "https://api.razorpay.com"],
        frameSrc: ["'self'", "https://api.razorpay.com", "https://checkout.razorpay.com"],
        styleSrc: ["'self'", "'unsafe-inline'"],
      },
    },
  }),
);

// CORS must run before rate limiting so errors (including a 429) are still
// readable by the mobile web preview instead of being reported as a network
// failure by the browser.
app.use(
  cors({
    origin: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
);

app.use(limiter);

app.use(express.json());

app.use("/uploads", express.static(path.join(__dirname, "../uploads")));

/* Swagger */

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.use("/api", routes);

app.use(errorHandler);

module.exports = app;
