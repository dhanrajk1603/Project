const axios = require("axios");
const recommendationService = require("../recommendations/recommendation.service");
const repo = require("./ai.repository");

const skillsText = (skills) =>
  skills.map((skill) => skill.skill_name).join(", ") || "no skills added yet";
const extractJson = (text, fallback) => {
  try {
    return JSON.parse(text.replace(/```json|```/g, "").trim());
  } catch {
    return fallback;
  }
};

async function generate(prompt, fallback) {
  if (!process.env.GEMINI_API_KEY) return fallback;
  try {
    const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.35,
          responseMimeType: "application/json",
        },
      },
      { timeout: 20000 },
    );
    const text = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;
    return text ? extractJson(text, fallback) : fallback;
  } catch (error) {
    console.error(
      "Gemini request failed:",
      error.response?.status || error.message,
    );
    return fallback;
  }
}

async function context(userId) {
  const [profileRows, skills] = await Promise.all([
    repo.getProfile(userId),
    repo.getSkills(userId),
  ]);
  return {
    profile: profileRows[0] || {},
    skills,
    skillNames: skillsText(skills),
  };
}

async function careerAdvice(userId) {
  const data = await context(userId);
  return generate(
    `You are a concise career mentor. User: ${data.profile.name || "Learner"}. Skills: ${data.skillNames}. Return JSON {"advice":[3 to 4 short actionable strings]}.`,
    {
      advice: [
        "Add your strongest skills to your profile.",
        "Build one portfolio project this week.",
        "Practice interview questions for your target role.",
      ],
    },
  );
}
async function profileSummary(userId) {
  const data = await context(userId);
  return generate(
    `Write a professional two-sentence profile summary for ${data.profile.name || "a developer"} with skills ${data.skillNames}. Return JSON {"summary":"..."}.`,
    {
      summary: `You are a career-focused professional with experience in ${data.skillNames}. Adding targeted projects and in-demand cloud skills can broaden your opportunities.`,
    },
  );
}
async function skillGap(userId) {
  const data = await context(userId);
  const jobs = await repo.getJobs();
  const jobSkills = (
    await Promise.all(jobs.slice(0, 10).map((job) => repo.getJobSkills(job.id)))
  )
    .flat()
    .map((x) => x.skill_name);
  const missing = [
    ...new Set(
      jobSkills.filter(
        (skill) =>
          !data.skills.some(
            (item) => item.skill_name.toLowerCase() === skill.toLowerCase(),
          ),
      ),
    ),
  ].slice(0, 8);
  return generate(
    `For current skills ${data.skillNames}, market missing skills are ${missing.join(", ")}. Return JSON {"currentSkills":string[],"missingSkills":string[],"suggestedSkills":string[]}.`,
    {
      currentSkills: data.skills.map((x) => x.skill_name),
      missingSkills: missing,
      suggestedSkills: missing.slice(0, 5),
    },
  );
}
async function roadmap(userId) {
  const data = await context(userId);
  return generate(
    `Create a six-step practical learning roadmap based on skills ${data.skillNames}. Return JSON {"roadmap":["step"]}.`,
    {
      roadmap: [
        ...data.skills.map((x) => x.skill_name).slice(0, 2),
        "TypeScript",
        "Node.js",
        "Docker",
        "System Design",
      ],
    },
  );
}
async function interviewQuestions(userId) {
  const data = await context(userId);
  return generate(
    `Create 8 interview questions based on skills ${data.skillNames}. Return JSON {"questions":["question"]}.`,
    {
      questions: data.skills
        .slice(0, 6)
        .map(
          (x) => `Explain a practical project where you used ${x.skill_name}.`,
        ),
    },
  );
}
async function careerScore(userId) {
  const data = await context(userId);
  const applicationRows = await repo.getProjectsAndApplications(userId);
  const score = Math.min(
    100,
    35 +
      data.skills.length * 8 +
      Number(applicationRows[0]?.applications || 0) * 3,
  );
  return generate(
    `Assess career readiness. Skills: ${data.skillNames}; applications: ${applicationRows[0]?.applications || 0}. Return JSON {"score":number,"breakdown":{"skills":number,"experience":number,"projects":number,"recommendations":number},"nextStep":"..."}.`,
    {
      score,
      breakdown: {
        skills: Math.min(40, data.skills.length * 8),
        experience: 15,
        projects: 10,
        recommendations: 10,
      },
      nextStep: "Complete a portfolio project and close your top skill gap.",
    },
  );
}
async function explainJob(userId, job) {
  const data = await context(userId);
  const required = await repo.getJobSkills(job.id);
  const fallback = {
    explanation: `Your ${data.skillNames} experience is relevant to this role.`,
    careerSuggestion: "Strengthen the most relevant project in your portfolio.",
    learningSuggestion: `Learn ${
      required
        .map((x) => x.skill_name)
        .filter((x) => !data.skillNames.includes(x))
        .slice(0, 2)
        .join(" and ") || "the job's core tools"
    }.`,
  };
  return generate(
    `User skills: ${data.skillNames}. Job: ${job.title}. Required skills: ${required.map((x) => x.skill_name).join(", ")}. Return JSON {"explanation":"...","careerSuggestion":"...","learningSuggestion":"..."}.`,
    fallback,
  );
}
async function explainCourse(userId, courseId) {
  const data = await context(userId);
  const course = (await repo.getCourse(courseId))[0];
  if (!course) throw new Error("Course not found");
  return generate(
    `User skills: ${data.skillNames}. Course: ${course.title}; description: ${course.description || ""}. Return JSON {"reason":"...","benefits":["..."],"nextLearningSuggestion":"..."}.`,
    {
      reason: `${course.title} complements your current skills and target career path.`,
      benefits: ["Build practical capability", "Broaden your job options"],
      nextLearningSuggestion:
        "Complete a small project using the course concepts.",
    },
  );
}

module.exports = {
  careerAdvice,
  profileSummary,
  skillGap,
  roadmap,
  interviewQuestions,
  careerScore,
  explainJob,
  explainCourse,
  generate,
};
