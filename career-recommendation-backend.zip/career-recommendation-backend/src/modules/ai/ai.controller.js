const service = require("./ai.service");
const respond = (fn) => async (req, res) => {
  try {
    res.json(await fn(req));
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
module.exports = {
  careerAdvice: respond((req) => service.careerAdvice(req.user.id)),
  profileSummary: respond((req) => service.profileSummary(req.user.id)),
  skillGap: respond((req) => service.skillGap(req.user.id)),
  roadmap: respond((req) => service.roadmap(req.user.id)),
  interviewQuestions: respond((req) => service.interviewQuestions(req.user.id)),
  careerScore: respond((req) => service.careerScore(req.user.id)),
  explainJob: respond((req) => service.explainJob(req.user.id, req.body)),
  explainCourse: respond((req) =>
    service.explainCourse(req.user.id, req.body.course_id),
  ),
};
