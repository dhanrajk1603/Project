const db = require("../../config/db");

const query = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.query(sql, params, (error, rows) =>
      error ? reject(error) : resolve(rows),
    );
  });

const getProfile = (userId) =>
  query("SELECT id, name, email, mobile FROM users WHERE id=?", [userId]);
const getSkills = (userId) =>
  query(
    `SELECT s.id, s.skill_name FROM user_skills us JOIN skills s ON s.id=us.skill_id WHERE us.user_id=?`,
    [userId],
  );
const getJobs = () => query("SELECT id, title, company, description FROM jobs");
const getJobSkills = (jobId) =>
  query(
    `SELECT s.skill_name FROM job_skills js JOIN skills s ON s.id=js.skill_id WHERE js.job_id=?`,
    [jobId],
  );
const getCourse = (courseId) =>
  query("SELECT id, title, description FROM courses WHERE id=?", [courseId]);
const getProjectsAndApplications = (userId) =>
  query(
    "SELECT COUNT(*) AS applications FROM job_applications WHERE user_id=?",
    [userId],
  );

module.exports = {
  getProfile,
  getSkills,
  getJobs,
  getJobSkills,
  getCourse,
  getProjectsAndApplications,
};
