const service = require("./payment.service");
const respond =
  (fn, status = 200) =>
  async (req, res) => {
    try {
      res.status(status).json(await fn(req));
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  };
const invoice = async (req, res) => {
  try {
    const result = await service.invoice(req.user.id, req.params.paymentId);
    res.set({
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename=invoice-${result.payment.payment_id}.pdf`,
    });
    res.send(result.pdf);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
const checkout = async (req, res) => {
  try {
    const payment = await service.checkout(req.params.token);
    const payload = JSON.stringify(payment).replace(/</g, "\\u003c");
    const scheme = process.env.APP_DEEP_LINK_SCHEME || "careerrecommendation";
    res
      .type("html")
      .send(
        `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Career Compass | Secure checkout</title><script src="https://checkout.razorpay.com/v1/checkout.js"></script><style>*{box-sizing:border-box}body{margin:0;min-height:100vh;background:#f4f7ff;color:#172033;font-family:system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;display:grid;place-items:center;padding:24px}.shell{width:min(100%,440px);overflow:hidden;border-radius:24px;background:#fff;box-shadow:0 18px 55px #15265a22}.brand{padding:28px;background:linear-gradient(135deg,#192a62,#4f46e5);color:#fff}.logo{width:42px;height:42px;display:grid;place-items:center;border-radius:13px;background:#fff;color:#4338ca;font-weight:900;font-size:21px}.brand h1{font-size:24px;margin:18px 0 7px}.brand p{margin:0;color:#dbeafe}.content{padding:26px}.label{font-size:12px;font-weight:800;letter-spacing:.08em;color:#64748b}.course{font-size:20px;font-weight:800;margin:7px 0 19px}.amount{display:flex;justify-content:space-between;align-items:center;background:#f8fafc;border-radius:14px;padding:15px;margin-bottom:20px}.amount strong{font-size:21px}.secure{display:flex;gap:10px;align-items:flex-start;font-size:13px;line-height:19px;color:#64748b;margin:0 0 20px}.lock{color:#16a34a;font-size:18px}button{background:#16a34a;border:0;border-radius:13px;color:#fff;font-size:16px;font-weight:800;padding:15px 20px;width:100%;cursor:pointer;box-shadow:0 9px 18px #16a34a33}button:hover{background:#15803d}.muted{color:#64748b;text-align:center;font-size:13px;min-height:20px;margin:14px 0 0}.powered{text-align:center;color:#94a3b8;font-size:12px;margin:17px 0 0}</style></head><body><main class="shell"><section class="brand"><div class="logo">C</div><h1>Career Compass</h1><p>Secure course checkout</p></section><section class="content"><div class="label">YOUR COURSE</div><div class="course" id="course"></div><div class="amount"><span>Total payable</span><strong id="amount"></strong></div><p class="secure"><span class="lock">🔒</span><span>Your payment is encrypted and processed securely by Razorpay. We do not store card or UPI details.</span></p><button id="pay">Continue to Razorpay</button><p class="muted" id="status"></p><p class="powered">Powered by Razorpay</p></section></main><script>const data=${payload};const status=document.getElementById('status');document.getElementById('course').textContent=data.courseTitle;document.getElementById('amount').textContent='₹ '+(data.amount/100).toFixed(2);const finish=(state,message)=>{status.textContent=message;if(window.opener){try{window.opener.postMessage({type:'payment-result',status:state},'*')}catch(e){}setTimeout(()=>{window.close()},1200)}setTimeout(()=>{location.href='${scheme}://payment-result?status='+state},200)};const complete=async(response)=>{status.textContent='Verifying payment…';const r=await fetch('/api/payments/checkout/complete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:data.token,...response})});const body=await r.json();if(!r.ok)throw new Error(body.message||'Verification failed');finish('success','Payment successful. Returning to app…')};document.getElementById('pay').onclick=async()=>{try{if(data.demo){await complete({razorpay_payment_id:'pay_demo_'+Date.now(),razorpay_signature:'demo'});return}const razorpay=new Razorpay({key:data.keyId,amount:data.amount,currency:'INR',name:'Career Compass',description:data.courseTitle,order_id:data.orderId,handler:complete,modal:{ondismiss:()=>finish('cancelled','Payment cancelled.')}});razorpay.open()}catch(error){status.textContent=error.message||'Unable to complete payment'}}</script></body></html>`,
      );
  } catch (error) {
    res
      .status(400)
      .type("html")
      .send(`<h2>Checkout unavailable</h2><p>${error.message}</p>`);
  }
};
module.exports = {
  createOrder: respond(
    (req) => service.createOrder(req.user.id, req.body.course_id),
    201,
  ),
  verify: respond((req) => service.verify(req.user.id, req.body)),
  createCourseOrder: respond(
    (req) => service.createOrder(req.user.id, req.params.courseId),
    201,
  ),
  verifyCoursePayment: respond((req) =>
    service.verify(req.user.id, req.body, req.params.courseId),
  ),
  history: respond((req) => service.history(req.user.id)),
  invoice,
  checkout,
  checkoutComplete: respond((req) =>
    service.completeCheckout(req.body.token, req.body),
  ),
};
