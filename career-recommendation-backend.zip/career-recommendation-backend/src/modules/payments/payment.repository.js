const db = require("../../config/db");
const query = (sql, params = []) =>
  new Promise((resolve, reject) =>
    db.query(sql, params, (error, rows) =>
      error ? reject(error) : resolve(rows),
    ),
  );
const getCourse = (id) =>
  query("SELECT id, title, price FROM courses WHERE id=?", [id]);
const create = (data) =>
  query(
    "INSERT INTO payments (user_id, course_id, razorpay_order_id, amount, status) VALUES (?, ?, ?, ?, 'created')",
    [data.userId, data.courseId, data.orderId, data.amount],
  );
const getOpenPayment = (userId, courseId) =>
  query(
    "SELECT * FROM payments WHERE user_id=? AND course_id=? AND status='created' ORDER BY created_at DESC LIMIT 1",
    [userId, courseId],
  );
const getPayment = (userId, orderId) =>
  query("SELECT * FROM payments WHERE user_id=? AND razorpay_order_id=?", [
    userId,
    orderId,
  ]);
const getEnrollment = (userId, courseId) =>
  query("SELECT id FROM enrollments WHERE user_id=? AND course_id=?", [
    userId,
    courseId,
  ]);
const completePaymentAndEnroll = ({ userId, orderId, paymentId }) =>
  new Promise((resolve, reject) => {
    db.getConnection((connectionError, connection) => {
      if (connectionError) return reject(connectionError);
      connection.beginTransaction((beginError) => {
        if (beginError) {
          connection.release();
          return reject(beginError);
        }
        connection.query(
          "SELECT * FROM payments WHERE user_id=? AND razorpay_order_id=? FOR UPDATE",
          [userId, orderId],
          (paymentError, payments) => {
            if (paymentError || !payments.length) {
              return connection.rollback(() => {
                connection.release();
                reject(paymentError || new Error("Payment order not found"));
              });
            }
            const payment = payments[0];
            if (payment.status === "paid") {
              connection.commit((commitError) => {
                connection.release();
                commitError ? reject(commitError) : resolve({ alreadyPaid: true });
              });
              return;
            }
            connection.query(
              "UPDATE payments SET razorpay_payment_id=?, status='paid' WHERE payment_id=? AND status='created'",
              [paymentId, payment.payment_id],
              (updateError, updateResult) => {
                if (updateError || updateResult.affectedRows !== 1) {
                  return connection.rollback(() => {
                    connection.release();
                    reject(updateError || new Error("Payment has already been processed"));
                  });
                }
                connection.query(
                  "INSERT INTO enrollments (user_id, course_id) VALUES (?, ?) ON DUPLICATE KEY UPDATE user_id=VALUES(user_id)",
                  [userId, payment.course_id],
                  (enrollmentError) => {
                    if (enrollmentError) {
                      return connection.rollback(() => {
                        connection.release();
                        reject(enrollmentError);
                      });
                    }
                    connection.commit((commitError) => {
                      connection.release();
                      commitError ? reject(commitError) : resolve({ alreadyPaid: false });
                    });
                  },
                );
              },
            );
          },
        );
      });
    });
  });
const history = (userId) =>
  query(
    `SELECT p.*, c.title AS course_title FROM payments p JOIN courses c ON c.id=p.course_id WHERE p.user_id=? ORDER BY p.created_at DESC`,
    [userId],
  );
const getInvoice = (userId, paymentId) =>
  query(
    `SELECT p.*, c.title AS course_title, u.name AS user_name, u.email AS user_email FROM payments p JOIN courses c ON c.id=p.course_id JOIN users u ON u.id=p.user_id WHERE p.payment_id=? AND p.user_id=?`,
    [paymentId, userId],
  );
module.exports = {
  getCourse,
  create,
  getOpenPayment,
  completePaymentAndEnroll,
  getPayment,
  getEnrollment,
  history,
  getInvoice,
};
