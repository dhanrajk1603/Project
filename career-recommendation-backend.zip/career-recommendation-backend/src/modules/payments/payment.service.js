const axios = require("axios");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");
const repo = require("./payment.repository");

const checkoutSecret = () => {
  if (!process.env.JWT_SECRET) throw new Error("JWT_SECRET is not configured");
  return process.env.JWT_SECRET;
};
const checkoutToken = (userId, orderId) =>
  jwt.sign({ userId, orderId, purpose: "payment-checkout" }, checkoutSecret(), {
    expiresIn: "20m",
  });
const publicApiUrl = () =>
  (
    process.env.PUBLIC_API_URL || `http://localhost:${process.env.PORT || 5000}`
  ).replace(/\/$/, "");

async function createOrder(userId, courseId) {
  const course = (await repo.getCourse(courseId))[0];
  if (!course) throw new Error("Course not found");
  if (!Number.isFinite(Number(course.price)) || Number(course.price) <= 0)
    throw new Error("This course has an invalid price");
  if ((await repo.getEnrollment(userId, courseId)).length)
    throw new Error("You are already enrolled in this course");

  const openPayment = (await repo.getOpenPayment(userId, courseId))[0];
  let order = openPayment
    ? {
        id: openPayment.razorpay_order_id,
        amount: Math.round(Number(openPayment.amount) * 100),
        currency: "INR",
      }
    : null;
  if (!order && process.env.DEMO_MODE === "true") {
    order = {
      id: `order_demo_${Date.now()}`,
      amount: Math.round(Number(course.price) * 100),
      currency: "INR",
    };
  } else if (!order) {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET)
      throw new Error(
        "Razorpay is not configured. Add test-mode Razorpay keys.",
      );
    const response = await axios.post(
      "https://api.razorpay.com/v1/orders",
      {
        amount: Math.round(Number(course.price) * 100),
        currency: "INR",
        receipt: `course_${courseId}_${Date.now()}`,
      },
      {
        auth: {
          username: process.env.RAZORPAY_KEY_ID,
          password: process.env.RAZORPAY_KEY_SECRET,
        },
      },
    );
    order = response.data;
  }
  if (!openPayment) {
    await repo.create({
      userId,
      courseId,
      orderId: order.id,
      amount: course.price,
    });
  }
  const token = checkoutToken(userId, order.id);
  return {
    order,
    course,
    keyId: process.env.RAZORPAY_KEY_ID || "",
    demo: process.env.DEMO_MODE === "true",
    checkout_url: `${publicApiUrl()}/api/payments/checkout/${encodeURIComponent(token)}`,
  };
}

async function verify(
  userId,
  { razorpay_order_id, razorpay_payment_id, razorpay_signature },
  expectedCourseId,
) {
  if (
    !razorpay_order_id ||
    !razorpay_payment_id ||
    (!razorpay_signature && process.env.DEMO_MODE !== "true")
  )
    throw new Error("Payment verification fields are required");
  if (process.env.DEMO_MODE !== "true") {
    const expected = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");
    const received = Buffer.from(razorpay_signature, "utf8");
    const expectedBuffer = Buffer.from(expected, "utf8");
    if (
      received.length !== expectedBuffer.length ||
      !crypto.timingSafeEqual(expectedBuffer, received)
    )
      throw new Error("Payment signature verification failed");
  }
  const payment = (await repo.getPayment(userId, razorpay_order_id))[0];
  if (!payment) throw new Error("Payment order not found");
  if (
    expectedCourseId &&
    Number(payment.course_id) !== Number(expectedCourseId)
  ) {
    throw new Error("Payment order does not belong to this course");
  }
  const result = await repo.completePaymentAndEnroll({
    userId,
    orderId: razorpay_order_id,
    paymentId: razorpay_payment_id,
  });
  return {
    message: result.alreadyPaid
      ? "Payment already verified"
      : "Payment verified and enrollment completed",
  };
}

async function checkout(token) {
  let session;
  try {
    session = jwt.verify(token, checkoutSecret());
  } catch {
    throw new Error("This checkout session has expired. Please start again.");
  }
  if (session.purpose !== "payment-checkout")
    throw new Error("Invalid checkout session");
  const payment = (await repo.getPayment(session.userId, session.orderId))[0];
  if (!payment) throw new Error("Payment order not found");
  const course = (await repo.getCourse(payment.course_id))[0];
  return {
    token,
    orderId: payment.razorpay_order_id,
    amount: Math.round(Number(payment.amount) * 100),
    courseTitle: course?.title || "Course",
    keyId: process.env.RAZORPAY_KEY_ID || "",
    demo: process.env.DEMO_MODE === "true",
  };
}

async function completeCheckout(token, paymentResponse) {
  const details = await checkout(token);
  const session = jwt.verify(token, checkoutSecret());
  await verify(session.userId, {
    razorpay_order_id: details.orderId,
    razorpay_payment_id: paymentResponse.razorpay_payment_id,
    razorpay_signature: paymentResponse.razorpay_signature,
  });
  return { message: "Payment successful" };
}

const escapePdf = (value) =>
  String(value).replace(/\\/g, "\\\\").replace(/[()]/g, "\\$&");
async function invoice(userId, paymentId) {
  const payment = (await repo.getInvoice(userId, paymentId))[0];
  if (!payment || payment.status !== "paid")
    throw new Error("Paid invoice not found");
  const lines = [
    "Career Recommendation Platform",
    "Payment Invoice",
    `Invoice: ${payment.payment_id}`,
    `Customer: ${payment.user_name} (${payment.user_email})`,
    `Course: ${payment.course_title}`,
    `Amount: INR ${payment.amount}`,
    `Transaction: ${payment.razorpay_payment_id}`,
    `Date: ${new Date(payment.created_at).toLocaleDateString("en-IN")}`,
  ];
  const content = `BT /F1 12 Tf 50 760 Td ${lines.map((line, i) => `${i ? "0 -24 Td " : ""}(${escapePdf(line)}) Tj`).join(" ")} ET`;
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
    `<< /Length ${Buffer.byteLength(content)} >>\nstream\n${content}\nendstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(Buffer.byteLength(pdf));
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xref = Buffer.byteLength(pdf);
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets
    .slice(1)
    .map((offset) => `${String(offset).padStart(10, "0")} 00000 n `)
    .join(
      "\n",
    )}\ntrailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return { payment, pdf: Buffer.from(pdf) };
}

module.exports = {
  createOrder,
  verify,
  checkout,
  completeCheckout,
  history: (userId) => repo.history(userId),
  invoice,
};
