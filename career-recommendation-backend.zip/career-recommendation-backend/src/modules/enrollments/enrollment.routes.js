const express = require("express");

const router = express.Router();

const verifyToken = require("../../middleware/auth.middleware");

const enrollmentController = require("./enrollment.controller");

// Paid courses must be enrolled through verified payment only.  Keep this
// endpoint so older clients receive a clear migration error instead of a 404.
router.post("/enroll", verifyToken, enrollmentController.paymentRequired);

router.get("/my-courses", verifyToken, enrollmentController.myCourses);

module.exports = router;
