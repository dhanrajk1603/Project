const db = require("../../config/db");
const query = (sql, params = []) =>
  new Promise((resolve, reject) =>
    db.query(sql, params, (error, rows) =>
      error ? reject(error) : resolve(rows),
    ),
  );
const updateApplicationResume = (userId, jobId, data) =>
  query(
    `INSERT INTO job_applications (user_id, job_id, resume_url, resume_public_id, resume_name) VALUES (?, ?, ?, ?, ?)`,
    [userId, jobId, data.url, data.publicId, data.name],
  );
const getResume = (userId, jobId) =>
  query("SELECT * FROM job_applications WHERE job_id=? AND user_id=?", [
    jobId,
    userId,
  ]);
const getJob = (jobId) => query("SELECT id FROM jobs WHERE id=?", [jobId]);
module.exports = { updateApplicationResume, getResume, getJob };
