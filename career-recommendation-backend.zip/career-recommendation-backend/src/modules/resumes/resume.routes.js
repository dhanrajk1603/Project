const router = require("express").Router();
const auth = require("../../middleware/auth.middleware");
const upload = require("../../middleware/resumeUpload.middleware");
const controller = require("./resume.controller");
router.post("/upload", auth, upload.single("resume"), controller.upload);
router.post("/review", auth, upload.single("resume"), controller.review);
module.exports = router;
