const service = require("./resume.service");
const upload = async (req, res) => {
  try {
    res
      .status(201)
      .json(await service.upload(req.user.id, req.body.job_id, req.file));
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
const review = async (req, res) => {
  try {
    res.json(await service.review(req.user.id, req.file));
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
module.exports = { upload, review };
