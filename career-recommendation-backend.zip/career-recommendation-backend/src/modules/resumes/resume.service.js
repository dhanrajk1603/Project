const crypto = require("crypto");
const axios = require("axios");
const ai = require("../ai/ai.service");
const repo = require("./resume.repository");

function cloudinaryConfig() {
  const {
    CLOUDINARY_CLOUD_NAME,
    CLOUDINARY_API_KEY,
    CLOUDINARY_API_SECRET,
  } = process.env;

  if (
    !CLOUDINARY_CLOUD_NAME ||
    !CLOUDINARY_API_KEY ||
    !CLOUDINARY_API_SECRET
  ) {
    throw new Error(
      "Cloudinary is not configured. Set CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY and CLOUDINARY_API_SECRET."
    );
  }

  return {
    CLOUDINARY_CLOUD_NAME,
    CLOUDINARY_API_KEY,
    CLOUDINARY_API_SECRET,
  };
}

async function uploadToCloudinary(file) {
  const config = cloudinaryConfig();

  const timestamp = Math.floor(Date.now() / 1000);
  const folder = "career-recommendation/resumes";

  // PDF -> image/upload
  // DOC/DOCX -> raw/upload
  const isPdf = file.mimetype === "application/pdf";
  const resourceType = isPdf ? "image" : "raw";

  const signature = crypto
    .createHash("sha1")
    .update(
      `folder=${folder}&timestamp=${timestamp}${config.CLOUDINARY_API_SECRET}`
    )
    .digest("hex");

  const form = new FormData();

  form.append(
    "file",
    new Blob([file.buffer], {
      type: file.mimetype,
    }),
    file.originalname
  );

  form.append("api_key", config.CLOUDINARY_API_KEY);
  form.append("timestamp", String(timestamp));
  form.append("folder", folder);
  form.append("signature", signature);

  const uploadUrl = `https://api.cloudinary.com/v1_1/${config.CLOUDINARY_CLOUD_NAME}/${resourceType}/upload`;

  const response = await axios.post(uploadUrl, form, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
    maxBodyLength: Infinity,
  });

  return {
    url: response.data.secure_url,
    publicId: response.data.public_id,
    name: file.originalname,
  };
}

const simpleText = (file) =>
  file.mimetype === "application/pdf"
    ? file.buffer
        .toString("latin1")
        .replace(/[^\x20-\x7E\n]/g, " ")
        .slice(0, 12000)
    : `Resume filename: ${file.originalname}. Please review the resume structure, skills, experience and projects.`;

async function upload(userId, jobId, file) {
  if (!file) {
    throw new Error("A PDF, DOC or DOCX resume is required");
  }

  if (!jobId) {
    throw new Error("job_id is required");
  }

  const job = await repo.getJob(jobId);

  if (!job.length) {
    throw new Error("Job not found");
  }

  const existing = await repo.getResume(userId, jobId);

  if (existing.length) {
    throw new Error("You have already applied for this job");
  }

  // Upload resume to Cloudinary
  const uploaded = await uploadToCloudinary(file);

  // Save Cloudinary URL in database
  await repo.updateApplicationResume(userId, jobId, uploaded);

  return {
    message: "Application submitted with resume",
    resume: uploaded,
  };
}

async function review(userId, file) {
  if (!file) {
    throw new Error("A resume file is required");
  }

  const text = simpleText(file);

  return ai.generate(
    `Review this job applicant resume text. Return JSON {"resumeScore":number,"atsScore":number,"suggestions":[exactly 10 concise improvements]}. Resume: ${text}`,
    {
      resumeScore: 65,
      atsScore: 60,
      suggestions: [
        "Add a focused professional summary.",
        "Use job-relevant keywords.",
        "Quantify project outcomes.",
        "Add a GitHub link.",
        "Add a LinkedIn link.",
        "Highlight technical skills.",
        "Use clear section headings.",
        "Describe REST API work.",
        "Describe authentication work.",
        "Proofread for consistency.",
      ],
    }
  );
}

module.exports = {
  upload,
  review,
};