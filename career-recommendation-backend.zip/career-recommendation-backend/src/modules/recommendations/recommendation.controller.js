const recommendationService = require("./recommendation.service");
const aiService = require("../ai/ai.service");

exports.jobs = async (req, res) => {
  try {
    const result = await recommendationService.recommendJobs(req.user.id);
    const enhanced = await Promise.all(result.map(async (job) => ({
      ...job,
      ai: await aiService.explainJob(req.user.id, job),
    })));

    res.status(200).json(enhanced);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

exports.courses = async (req, res) => {
  try {
    const result = await recommendationService.recommendCourses(req.user.id);
    const uniqueCourses = result.filter((course, index, list) => list.findIndex((item) => item.id === course.id) === index);
    const enhanced = await Promise.all(uniqueCourses.map(async (course) => ({
      ...course,
      ai: await aiService.explainCourse(req.user.id, course.id),
    })));

    res.status(200).json(enhanced);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};
