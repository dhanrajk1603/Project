const db = require("../../config/db");

const applyJob = (userId, jobId) => {
  return new Promise((resolve, reject) => {
    db.query(
      `INSERT INTO job_applications
      (user_id, job_id)
      VALUES(?, ?)`,
      [userId, jobId],
      (err, result) => {
        if (err) reject(err);
        else resolve(result);
      }
    );
  });
};

const checkApplication = (userId, jobId) => {
  return new Promise((resolve, reject) => {
    db.query(
      `SELECT *
       FROM job_applications
       WHERE user_id=? AND job_id=?`,
      [userId, jobId],
      (err, result) => {
        if (err) reject(err);
        else resolve(result);
      }
    );
  });
};

const getMyApplications = (userId) => {
  return new Promise((resolve, reject) => {
    db.query(
      `SELECT
          ja.id,
          ja.status,
          ja.applied_at,
          ja.resume_url,
          ja.resume_name,
          j.id AS job_id,
          j.title,
          j.company,
          j.location,
          j.salary,
          j.description
       FROM job_applications ja
       JOIN jobs j
       ON ja.job_id = j.id
       WHERE ja.user_id=?
       ORDER BY ja.applied_at DESC`,
      [userId],
      (err, result) => {
        if (err) reject(err);
        else resolve(result);
      }
    );
  });
};

const getAllApplications = () => new Promise((resolve, reject) => {
  db.query(`SELECT ja.id, ja.status, ja.applied_at, ja.resume_url, ja.resume_name, j.title, j.company, u.name AS user_name, u.email AS user_email
    FROM job_applications ja JOIN jobs j ON j.id=ja.job_id JOIN users u ON u.id=ja.user_id ORDER BY ja.applied_at DESC`, (err, result) => (err ? reject(err) : resolve(result)));
});

const getApplicationById = (applicationId) =>
  new Promise((resolve, reject) => {
    db.query(
      "SELECT id, resume_url, resume_name FROM job_applications WHERE id=?",
      [applicationId],
      (err, result) => (err ? reject(err) : resolve(result)),
    );
  });

module.exports = {
  applyJob,
  checkApplication,
  getMyApplications,
  getAllApplications,
  getApplicationById,
};
