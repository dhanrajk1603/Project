const jobApplicationRepo = require("./jobApplication.repository");
const axios = require("axios");

const invalidResume = (message, status = 400) => {
  const error = new Error(message);
  error.status = status;
  return error;
};

const isCloudinaryUrl = (value) => {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && url.hostname === "res.cloudinary.com";
  } catch {
    return false;
  }
};

const safeFilename = (filename) =>
  String(filename || "resume").replace(/[\\\\/:*?"<>|\r\n]+/g, "_");

const apply = async (userId, jobId) => {

  const existing = await jobApplicationRepo.checkApplication(
    userId,
    jobId
  );

  if (existing.length > 0) {
    throw new Error("You have already applied for this job");
  }

  await jobApplicationRepo.applyJob(userId, jobId);

  return {
    message: "Job Applied Successfully",
  };
};

const myApplications = async (userId) => {

  return await jobApplicationRepo.getMyApplications(userId);

};

const allApplications = async () => jobApplicationRepo.getAllApplications();

const getDownloadableResume = async (applicationId) => {
  const application = (await jobApplicationRepo.getApplicationById(applicationId))[0];
  if (!application || !application.resume_url) {
    throw invalidResume("Resume is not available", 404);
  }
  if (!isCloudinaryUrl(application.resume_url)) {
    throw invalidResume(
      "This resume was stored on the previous local server. Ask the candidate to upload it again.",
      410,
    );
  }

  const response = await axios.get(application.resume_url, {
    responseType: "stream",
    timeout: 30000,
    maxRedirects: 3,
  });
  return {
    stream: response.data,
    contentType: response.headers["content-type"] || "application/octet-stream",
    filename: safeFilename(application.resume_name),
  };
};

module.exports = {
  apply,
  myApplications,
  allApplications,
  getDownloadableResume,
};
