const jobApplicationService = require("./jobApplication.service");

const apply = async (req, res) => {
  try {

    const userId = req.user.id;
    const { job_id } = req.body;

    const result = await jobApplicationService.apply(
      userId,
      job_id
    );

    res.status(201).json(result);

  } catch (error) {

    res.status(400).json({
      message: error.message,
    });

  }
};

const myApplications = async (req, res) => {
  try {

    const result =
      await jobApplicationService.myApplications(
        req.user.id
      );

    res.status(200).json(result);

  } catch (error) {

    res.status(500).json({
      message: error.message,
    });

  }
};

const allApplications = async (req, res) => {
  try { res.status(200).json(await jobApplicationService.allApplications()); }
  catch (error) { res.status(500).json({ message: error.message }); }
};

const downloadResume = async (req, res) => {
  try {
    const resume = await jobApplicationService.getDownloadableResume(
      req.params.applicationId,
    );
    res.set({
      "Content-Type": resume.contentType,
      "Content-Disposition": `attachment; filename="${resume.filename}"`,
      "Cache-Control": "private, no-store",
    });
    resume.stream.pipe(res);
  } catch (error) {
    res.status(error.status || 400).json({ message: error.message });
  }
};

module.exports = {
  apply,
  myApplications,
  allApplications,
  downloadResume,
};
