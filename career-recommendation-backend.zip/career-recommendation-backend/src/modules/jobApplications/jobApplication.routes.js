const express = require("express");

const router = express.Router();

const verifyToken = require("../../middleware/auth.middleware");
const isAdmin = require("../../middleware/admin.middleware");

const jobApplicationController = require("./jobApplication.controller");
const resumeUpload = require("../../middleware/resumeUpload.middleware");
const resumeController = require("../resumes/resume.controller");

// Apply Job
router.post(
  "/apply",
  verifyToken,
  resumeUpload.single("resume"),
  resumeController.upload
);

// My Applied Jobs
router.get(
  "/my-applications",
  verifyToken,
  jobApplicationController.myApplications
);
router.get("/all", verifyToken, isAdmin, jobApplicationController.allApplications);
router.get(
  "/:applicationId/resume",
  verifyToken,
  isAdmin,
  jobApplicationController.downloadResume,
);

module.exports = router;
