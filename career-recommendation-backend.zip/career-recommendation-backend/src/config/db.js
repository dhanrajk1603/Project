const mysql = require("mysql2");
const fs = require("fs");

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  ssl: {
    ca: fs.readFileSync("./ca.pem"),
    rejectUnauthorized: false,
  },
});

pool.getConnection((err, connection) => {
  if (err) {
    console.log("Database Error:", err);
  } else {
    console.log("Database Connected");
    connection.release();
  }
});

module.exports = pool;
