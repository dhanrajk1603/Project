const errorHandler = (err, req, res, next) => {
  console.error(err);

  const isUploadError = err.name === "MulterError";
  res.status(err.status || (isUploadError ? 400 : 500)).json({
    success: false,

    message: err.message || "Internal Server Error",
  });
};

module.exports = errorHandler;
