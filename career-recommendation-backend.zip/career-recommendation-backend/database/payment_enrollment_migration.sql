-- Run this once against TiDB/MySQL before deploying the payment changes.
-- It creates the payment ledger if it was not installed by an earlier migration.
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  razorpay_payment_id VARCHAR(255) NULL,
  razorpay_order_id VARCHAR(255) NOT NULL UNIQUE,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('created', 'paid', 'failed') NOT NULL DEFAULT 'created',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_payments_user (user_id),
  INDEX idx_payments_user_course_status (user_id, course_id, status),
  CONSTRAINT fk_payments_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_payments_course FOREIGN KEY (course_id) REFERENCES courses(id)
);

-- This query must return zero rows before adding the unique constraint. It
-- reports existing duplicate enrollments without deleting or changing data.
SELECT user_id, course_id, COUNT(*) AS duplicate_count
FROM enrollments
GROUP BY user_id, course_id
HAVING COUNT(*) > 1;

-- Run only after the duplicate check is empty. This makes the verified-payment
-- transaction safe when two payment callbacks arrive at the same time.
ALTER TABLE enrollments
  ADD CONSTRAINT uq_enrollments_user_course UNIQUE (user_id, course_id);
