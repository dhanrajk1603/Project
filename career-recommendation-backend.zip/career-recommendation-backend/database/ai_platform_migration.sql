-- Run once against the application MySQL database before enabling resume and payment features.
ALTER TABLE job_applications ADD COLUMN resume_url VARCHAR(1024) NULL, ADD COLUMN resume_public_id VARCHAR(255) NULL, ADD COLUMN resume_name VARCHAR(255) NULL;
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  razorpay_payment_id VARCHAR(255) NULL,
  razorpay_order_id VARCHAR(255) NOT NULL UNIQUE,
  amount DECIMAL(10,2) NOT NULL,
  status ENUM('created','paid','failed') NOT NULL DEFAULT 'created',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_payments_user (user_id),
  CONSTRAINT fk_payments_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_payments_course FOREIGN KEY (course_id) REFERENCES courses(id)
);
