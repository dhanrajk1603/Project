import { Navigate } from "react-router-dom";

function ProtectedRoute({ children }) {
  const token = localStorage.getItem("token");

  const user = JSON.parse(localStorage.getItem("user"));

  if (!token) {
    return <Navigate to="/" />;
  }

  if (!user || user.role !== "admin") {
    return <Navigate to="/user-dashboard" />;
  }

  return children;
}

export default ProtectedRoute;
