import { NavLink, useNavigate } from "react-router-dom";
import {
  FiBookOpen,
  FiBriefcase,
  FiGrid,
  FiLogOut,
  FiTag,
  FiUser,
  FiUsers,
} from "react-icons/fi";

function Sidebar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const linkClass = ({ isActive }) =>
    `side-link${isActive ? " side-link-active" : ""}`;

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    navigate("/");
  };

  return (
    <aside className="admin-sidebar">
      <div className="brand">
        <div className="brand-mark">C</div>
        <div>
          <strong>Career Compass</strong>
          <span>Management portal</span>
        </div>
      </div>

      <nav className="side-nav">
        <p className="side-label">MAIN MENU</p>
        {user?.role === "admin" && (
          <>
            <NavLink to="/dashboard" className={linkClass}><FiGrid /> Dashboard</NavLink>
            <NavLink to="/categories" className={linkClass}><FiTag /> Categories</NavLink>
            <NavLink to="/courses" className={linkClass}><FiBookOpen /> Courses</NavLink>
            <NavLink to="/jobs" className={linkClass}><FiBriefcase /> Jobs</NavLink>
            <NavLink to="/skills" className={linkClass}><FiUser /> Skills</NavLink>
            <NavLink to="/users" className={linkClass}><FiUsers /> Users</NavLink>
            <NavLink to="/applications" className={linkClass}><FiBriefcase /> Applications</NavLink>
          </>
        )}
        {user?.role === "user" && (
          <>
            <NavLink to="/user-dashboard" className={linkClass}><FiGrid /> Dashboard</NavLink>
            <NavLink to="/profile" className={linkClass}><FiUser /> My Profile</NavLink>
            <NavLink to="/my-skills" className={linkClass}><FiTag /> My Skills</NavLink>
            <NavLink to="/user-courses" className={linkClass}><FiBookOpen /> Courses</NavLink>
            <NavLink to="/user-jobs" className={linkClass}><FiBriefcase /> Jobs</NavLink>
            <NavLink to="/recommendations" className={linkClass}><FiGrid /> Recommendations</NavLink>
          </>
        )}
      </nav>

      <button className="logout-button" onClick={logout}><FiLogOut /> Logout</button>
    </aside>
  );
}

export default Sidebar;
