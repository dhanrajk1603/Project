import Sidebar from "../components/Sidebar";

function AdminLayout({ children }) {
  const user = JSON.parse(localStorage.getItem("user") || "null");

  return (
    <div className="admin-shell">
      <Sidebar />

      <main className="admin-main">
        <header className="admin-topbar">
          <div>
            <p className="topbar-kicker">Career Compass</p>
            <p className="topbar-date">{new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}</p>
          </div>
          <div className="topbar-profile">
            <div className="profile-avatar">{(user?.name || "A").charAt(0).toUpperCase()}</div>
            <div><strong>{user?.name || "Administrator"}</strong><span>{user?.role === "admin" ? "Administrator" : "Member"}</span></div>
          </div>
        </header>
        <div className="admin-content">
          {children}
        </div>
      </main>
    </div>
  );
}

export default AdminLayout;
