import { useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { FiArrowRight, FiLock, FiMail } from "react-icons/fi";

function Login() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await api.post("/auth/login", form);

      localStorage.setItem("token", res.data.token);

      localStorage.setItem("user", JSON.stringify(res.data.user));

      toast.success("Login Success");

      if (res.data.user.role === "admin") {
        navigate("/dashboard");
      } else {
        navigate("/user-dashboard");
      }
    } catch (error) {
      toast.error(error.response?.data?.message || "Login Failed");
    }
  };

  return (
    <main className="login-page">
      <section className="login-panel">
        <div className="login-brand"><div className="brand-mark">C</div><div><strong>Career Compass</strong><span>Management portal</span></div></div>
        <div className="login-copy"><p className="eyebrow">WELCOME BACK</p><h1>Sign in to your workspace</h1><p>Manage careers, courses, and opportunities from one place.</p></div>

              <form onSubmit={handleSubmit}>
                <label>Email address</label><div className="login-input"><FiMail /><input type="email" name="email" placeholder="you@example.com" onChange={handleChange} required /></div>

                <label>Password</label><div className="login-input"><FiLock /><input type="password" name="password" placeholder="Enter your password" onChange={handleChange} required /></div>

                <button className="login-button">Sign in <FiArrowRight /></button>
              </form>
      </section>
      <aside className="login-aside"><div className="login-orbit orbit-one" /><div className="login-orbit orbit-two" /><div className="login-message"><span>CAREER COMPASS</span><h2>Guide every learner toward their next opportunity.</h2><p>One simple platform for skills, courses, jobs and career growth.</p></div></aside>
    </main>
  );
}

export default Login;
