import { useEffect, useState } from "react";
import { FiBookOpen, FiCheckCircle, FiTag } from "react-icons/fi";
import { toast } from "react-toastify";
import api from "../services/api";
import AdminLayout from "../layouts/AdminLayout";

const loadCheckout = () => new Promise((resolve, reject) => { if (window.Razorpay) return resolve(); const script = document.createElement("script"); script.src = "https://checkout.razorpay.com/v1/checkout.js"; script.onload = resolve; script.onerror = reject; document.body.appendChild(script); });
export default function UserCourses() {
  const [courses, setCourses] = useState([]); const [enrolled, setEnrolled] = useState(new Set()); const [submittingId, setSubmittingId] = useState(null);
  useEffect(() => { (async () => { try { const headers = { Authorization: `Bearer ${localStorage.getItem("token")}` }; const [courseResponse, enrollmentResponse] = await Promise.all([api.get("/courses"), api.get("/enrollments/my-courses", { headers })]); setCourses(courseResponse.data); setEnrolled(new Set(enrollmentResponse.data.map((item) => item.id))); } catch { toast.error("Could not load courses."); } })(); }, []);
  const buy = async (courseId) => {
    try {
      setSubmittingId(courseId);
      const headers = { Authorization: `Bearer ${localStorage.getItem("token")}` };
      const response = await api.post("/payment/create-order", { course_id: courseId }, { headers });
      if (response.data.demo) {
        const token = response.data.checkout_url.split("/").pop();
        await api.post("/payment/checkout/complete", { token, razorpay_payment_id: "pay_demo_" + Date.now(), razorpay_signature: "demo" }, { headers });
        setEnrolled((current) => new Set([...current, courseId]));
        toast.success("Payment successful. You are enrolled!");
        return;
      }
      await loadCheckout();
      new window.Razorpay({
        key: response.data.keyId,
        amount: response.data.order.amount,
        currency: response.data.order.currency,
        name: "Career Compass",
        description: response.data.course.title,
        order_id: response.data.order.id,
        handler: async (payment) => {
          await api.post("/payment/verify", payment, { headers });
          setEnrolled((current) => new Set([...current, courseId]));
          toast.success("Payment successful. You are enrolled!");
        }
      }).open();
    } catch (error) {
      toast.error(error.response?.data?.message || "Could not start payment.");
    } finally {
      setSubmittingId(null);
    }
  };
  return <AdminLayout><section className="catalog-heading"><div><p className="eyebrow">LEARNING PATH</p><h2>Build your skills</h2><p>Securely pay before enrolling in a course.</p></div><span className="catalog-count">{courses.length} courses available</span></section><div className="course-grid">{courses.map((course) => { const isEnrolled = enrolled.has(course.id); return <article className="course-catalog-card" key={course.id}>{course.thumbnail ? <img src={course.thumbnail} alt="" className="course-thumbnail" /> : <div className="course-cover"><FiBookOpen /></div>}<div className="course-body"><div className="course-category"><FiTag /> {course.category_name || "Career course"}</div><h3>{course.title}</h3><p>{course.description}</p><div className="course-footer"><strong>₹{course.price}</strong><button className={isEnrolled ? "action-button applied" : "action-button"} disabled={isEnrolled || submittingId === course.id} onClick={() => buy(course.id)}>{isEnrolled ? <><FiCheckCircle /> Enrolled</> : <><FiBookOpen /> {submittingId === course.id ? "Opening payment..." : "Buy course"}</>}</button></div></div></article>; })}</div></AdminLayout>;
}
