import { useEffect, useState } from "react";
import { FiBookOpen, FiBriefcase, FiCheckCircle, FiPlus } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import AdminLayout from "../layouts/AdminLayout";

function Recommendations() {
  const navigate = useNavigate();
  const [data, setData] = useState({ jobs: [], courses: [], applications: [], enrollments: [], skills: [] });

  useEffect(() => {
    const load = async () => {
      try {
        const token = localStorage.getItem("token");
        const headers = { Authorization: `Bearer ${token}` };
        const [jobsRes, coursesRes, applicationsRes, enrollmentsRes, skillsRes] = await Promise.all([
          api.get("/recommendations/jobs", { headers }), api.get("/recommendations/courses", { headers }),
          api.get("/job-applications/my-applications", { headers }), api.get("/enrollments/my-courses", { headers }), api.get("/skills/my-skills", { headers }),
        ]);
        setData({ jobs: jobsRes.data, courses: coursesRes.data, applications: applicationsRes.data, enrollments: enrollmentsRes.data, skills: skillsRes.data });
      } catch (error) { console.error("Unable to load recommendations", error); }
    };
    load();
  }, []);

  return <AdminLayout>
    <section className="catalog-heading"><div><p className="eyebrow">CAREER RECOMMENDATIONS</p><h2>Designed for your next step</h2><p>Recommendations are based on the skills in your profile.</p></div><span className="catalog-count">{data.skills.length} skills added</span></section>
    {!data.skills.length && <section className="recommendation-empty"><FiPlus /><div><h3>Personalize your recommendations</h3><p>Add skills to your profile and we will match you with the most relevant jobs and courses.</p></div><button className="action-button" onClick={() => navigate("/my-skills")}>Add skills</button></section>}
    <div className="recommendation-layout"><section className="data-panel"><div className="panel-heading"><div><h3>Recommended jobs</h3><p>Roles that match your current skills</p></div><button className="text-link" onClick={() => navigate("/user-jobs")}>View all jobs</button></div><div className="activity-list">{data.jobs.map((job) => <div className="activity-row" key={job.id}><span className="activity-icon job-icon"><FiBriefcase /></span><div><strong>{job.title}</strong><p>{job.company}</p></div><span className="match-badge">{job.match_percentage}% match</span></div>)}{!data.jobs.length && <p className="empty-copy">No job matches yet. Add relevant skills to improve your matches.</p>}</div></section>
      <section className="data-panel"><div className="panel-heading"><div><h3>Recommended courses</h3><p>Skills that can strengthen your profile</p></div><button className="text-link" onClick={() => navigate("/user-courses")}>View all courses</button></div><div className="activity-list">{data.courses.map((course) => <div className="activity-row" key={`${course.id}-${course.skill_name}`}><span className="activity-icon course-icon"><FiBookOpen /></span><div><strong>{course.title}</strong><p>Build {course.skill_name} · ₹{course.price}</p></div></div>)}{!data.courses.length && <p className="empty-copy">No course recommendations yet. Add skills to personalise your learning path.</p>}</div></section></div>
    <section className="progress-banner activity-banner"><div><span className="progress-icon"><FiCheckCircle /></span><div><h3>Your activity</h3><p>You have applied to <strong>{data.applications.length}</strong> jobs and enrolled in <strong>{data.enrollments.length}</strong> courses. This progress is also visible on your dashboard.</p></div></div></section>
  </AdminLayout>;
}
export default Recommendations;
