import { useEffect, useState } from "react";
import { FiBookOpen, FiBriefcase, FiCompass, FiPlus, FiStar } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import AdminLayout from "../layouts/AdminLayout";

function UserDashboard() {
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const navigate = useNavigate();
  const [data, setData] = useState({ skills: [], applications: [], courses: [], recommendations: [] });

  useEffect(() => {
    const load = async () => {
      try {
        const token = localStorage.getItem("token");
        const headers = { Authorization: `Bearer ${token}` };
        const [skillsRes, applicationsRes, coursesRes, recommendationsRes] = await Promise.all([
          api.get("/skills/my-skills", { headers }),
          api.get("/job-applications/my-applications", { headers }),
          api.get("/enrollments/my-courses", { headers }),
          api.get("/recommendations/jobs", { headers }),
        ]);
        setData({ skills: skillsRes.data, applications: applicationsRes.data, courses: coursesRes.data, recommendations: recommendationsRes.data });
      } catch (error) { console.error("Unable to load career progress", error); }
    };
    load();
  }, []);

  const cards = [
    { label: "My skills", value: data.skills.length, icon: FiStar, action: () => navigate("/my-skills"), tone: "violet" },
    { label: "Jobs applied", value: data.applications.length, icon: FiBriefcase, action: () => navigate("/user-jobs"), tone: "orange" },
    { label: "Courses enrolled", value: data.courses.length, icon: FiBookOpen, action: () => navigate("/user-courses"), tone: "teal" },
    { label: "Career matches", value: data.recommendations.length, icon: FiCompass, action: () => navigate("/recommendations"), tone: "pink" },
  ];

  return <AdminLayout>
    <section className="user-welcome"><div><p className="eyebrow">MY CAREER SPACE</p><h2>Welcome back, {user?.name?.split(" ")[0] || "there"}</h2><p>Track your applications, learning, and personalized career opportunities.</p></div><button className="quick-add" onClick={() => navigate("/my-skills")}><FiPlus /> Add a skill</button></section>
    <div className="stat-grid user-stat-grid">{cards.map(({ label, value, icon: Icon, action, tone }) => <button className="stat-card stat-card-button" onClick={action} key={label}><div className={`stat-icon ${tone}`}><Icon /></div><p>{label}</p><strong>{value}</strong><span>View details →</span></button>)}</div>
    <section className="progress-banner"><div><span className="progress-icon"><FiCompass /></span><div><h3>Your career progress</h3><p>{data.skills.length ? `You have built a profile with ${data.skills.length} skills. Keep learning and applying to unlock more matches.` : "Add your skills to unlock job matches and personalized course recommendations."}</p></div></div>{!data.skills.length && <button onClick={() => navigate("/my-skills")}>Add skills</button>}</section>
    <div className="dashboard-tables"><section className="data-panel"><div className="panel-heading"><div><h3>Recent applications</h3><p>Your latest job applications</p></div><button className="text-link" onClick={() => navigate("/user-jobs")}>Explore jobs</button></div><div className="activity-list">{data.applications.slice(0, 4).map((job) => <div className="activity-row" key={job.id}><span className="activity-icon job-icon"><FiBriefcase /></span><div><strong>{job.title}</strong><p>{job.company} · {job.location}</p></div><span className="status-badge">{job.status || "Applied"}</span></div>)}{!data.applications.length && <p className="empty-copy">No applications yet. Find a role that fits your goals.</p>}</div></section>
      <section className="data-panel"><div className="panel-heading"><div><h3>My learning</h3><p>Courses you have enrolled in</p></div><button className="text-link" onClick={() => navigate("/user-courses")}>Explore courses</button></div><div className="activity-list">{data.courses.slice(0, 4).map((course) => <div className="activity-row" key={course.id}><span className="activity-icon course-icon"><FiBookOpen /></span><div><strong>{course.title}</strong><p>{course.category_name || "Career course"}</p></div><span className="status-badge enrolled">Enrolled</span></div>)}{!data.courses.length && <p className="empty-copy">No courses enrolled yet. Start learning today.</p>}</div></section></div>
  </AdminLayout>;
}
export default UserDashboard;
