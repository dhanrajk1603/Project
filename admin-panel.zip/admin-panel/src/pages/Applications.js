import { useEffect, useState } from "react";
import { FiDownload, FiExternalLink } from "react-icons/fi";
import AdminLayout from "../layouts/AdminLayout";
import api from "../services/api";

export default function Applications() {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const token = localStorage.getItem("token");

        const response = await api.get("/job-applications/all", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        console.log("APPLICATION DATA:", response.data);

        setApplications(response.data);
      } catch (error) {
        console.error("Unable to load applications:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchApplications();
  }, []);

  const isCloudinaryResume = (resumeUrl) => {
    try {
      const url = new URL(resumeUrl);
      return url.protocol === "https:" && url.hostname === "res.cloudinary.com";
    } catch {
      return false;
    }
  };

  const isLegacyResume = (resumeUrl) => !isCloudinaryResume(resumeUrl);

  const showLegacyResumeMessage = () => {
    alert(
      "This resume is from the previous local storage and can no longer be retrieved. Please ask the candidate to upload it again."
    );
  };

  const getDownloadErrorMessage = async (error) => {
    const body = error.response?.data;
    if (body instanceof Blob) {
      try {
        const parsed = JSON.parse(await body.text());
        return parsed.message;
      } catch {
        return "Unable to download the resume. Please try again.";
      }
    }
    return body?.message || "Unable to download the resume. Please try again.";
  };

  const downloadResume = async (applicationId, resumeUrl, resumeName) => {
    if (!resumeUrl) {
      alert("Resume is not available.");
      return;
    }

    if (isLegacyResume(resumeUrl)) {
      showLegacyResumeMessage();
      return;
    }

    try {
      const token = localStorage.getItem("token");
      const response = await api.get(
        `/job-applications/${applicationId}/resume`,
        {
          responseType: "blob",
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const blob = response.data;

      const blobUrl = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = resumeName || "resume.pdf";

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error("Resume download error:", error);
      alert(await getDownloadErrorMessage(error));
    }
  };

  const viewResume = (resumeUrl) => {
    if (isLegacyResume(resumeUrl)) {
      showLegacyResumeMessage();
      return;
    }
    // The Cloudinary delivery URL is opened unchanged so PDF inline viewing
    // remains available when the browser and the asset delivery permit it.
    window.open(resumeUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <AdminLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold">
            APPLICATIONS
          </h1>

          <p className="text-gray-500">
            Candidate resumes
          </p>

          <p className="text-gray-500">
            Review uploaded resumes and application status.
          </p>
        </div>

        {/* Table */}
        <div className="overflow-x-auto bg-white rounded-lg shadow">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4">
                  Candidate
                </th>

                <th className="text-left p-4">
                  Job
                </th>

                <th className="text-left p-4">
                  Resume
                </th>

                <th className="text-left p-4">
                  Status
                </th>

                <th className="text-left p-4">
                  Applied
                </th>
              </tr>
            </thead>

            <tbody>
              {loading ? (
                <tr>
                  <td
                    colSpan="5"
                    className="p-6 text-center"
                  >
                    Loading applications...
                  </td>
                </tr>
              ) : applications.length === 0 ? (
                <tr>
                  <td
                    colSpan="5"
                    className="p-6 text-center"
                  >
                    No applications found.
                  </td>
                </tr>
              ) : (
                applications.map((item) => (
                  <tr
                    key={item.id}
                    className="border-b hover:bg-gray-50"
                  >
                    {/* Candidate */}
                    <td className="p-4">
                      <div className="font-medium">
                        {item.user_name}
                      </div>

                      <div className="text-sm text-gray-500">
                        {item.user_email}
                      </div>
                    </td>

                    {/* Job */}
                    <td className="p-4">
                      <div className="font-medium">
                        {item.title}
                      </div>

                      <div className="text-sm text-gray-500">
                        {item.company}
                      </div>
                    </td>

                    {/* Resume */}
                    <td className="p-4">
                      {item.resume_url ? (
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() =>
                              viewResume(item.resume_url)
                            }
                            className="flex items-center gap-2 text-blue-600 hover:text-blue-800"
                          >
                            <FiExternalLink />
                            <span>View</span>
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              downloadResume(
                                item.id,
                                item.resume_url,
                                item.resume_name
                              )
                            }
                            className="flex items-center gap-2 text-blue-600 hover:text-blue-800"
                          >
                            <FiDownload />
                            <span>{item.resume_name || "Download"}</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-gray-400">
                          Not uploaded
                        </span>
                      )}
                    </td>

                    {/* Status */}
                    <td className="p-4">
                      {item.status}
                    </td>

                    {/* Applied Date */}
                    <td className="p-4">
                      {item.applied_at
                        ? new Date(
                            item.applied_at
                          ).toLocaleDateString()
                        : "-"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
