import { useEffect, useState } from "react";
import api from "../services/api";
import AdminLayout from "../layouts/AdminLayout";
import { FiBookOpen, FiBriefcase, FiTrendingUp, FiUsers } from "react-icons/fi";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

function Dashboard() {
  const [stats, setStats] = useState({});

  useEffect(() => {
    const fetchDashboard = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await api.get("/dashboard/stats", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setStats(res.data);
      } catch (error) {
        console.error("Unable to load dashboard", error);
      }
    };
    fetchDashboard();
  }, []);

  const chartData = [
    { name: "Users", count: stats.totalUsers || 0 },
    { name: "Courses", count: stats.totalCourses || 0 },
    { name: "Jobs", count: stats.totalJobs || 0 },
    { name: "Enrollments", count: stats.totalEnrollments || 0 },
  ];
  const cards = [
    {
      label: "Total users",
      value: stats.totalUsers || 0,
      icon: FiUsers,
      tone: "violet",
    },
    {
      label: "Published courses",
      value: stats.totalCourses || 0,
      icon: FiBookOpen,
      tone: "teal",
    },
    {
      label: "Active jobs",
      value: stats.totalJobs || 0,
      icon: FiBriefcase,
      tone: "orange",
    },
    {
      label: "Course enrollments",
      value: stats.totalEnrollments || 0,
      icon: FiTrendingUp,
      tone: "pink",
    },
  ];

  return (
    <AdminLayout>
      <section className="dashboard-heading">
        <div>
          <p className="eyebrow">OVERVIEW</p>
          <h2>Welcome back, Admin</h2>
          <p>Here is what is happening across your platform today.</p>
        </div>
      </section>

      <div className="stat-grid">
        {cards.map(({ label, value, icon: Icon, tone }) => (
          <article className="stat-card" key={label}>
            <div className={`stat-icon ${tone}`}>
              <Icon />
            </div>
            <p>{label}</p>
            <strong>{value}</strong>
            <span>Live platform total</span>
          </article>
        ))}
      </div>

      <section className="chart-panel">
        <div className="panel-heading">
          <div>
            <h3>Platform activity</h3>
            <p>Current totals across Career Compass</p>
          </div>
          <span className="live-badge">● Live data</span>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData} barSize={36}>
            <CartesianGrid vertical={false} stroke="#edf0f6" />
            <XAxis
              dataKey="name"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "#718096", fontSize: 12 }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: "#718096", fontSize: 12 }}
              allowDecimals={false}
            />
            <Tooltip
              cursor={{ fill: "#f5f3ff" }}
              contentStyle={{ borderRadius: 12, border: "1px solid #e8edf5" }}
            />
            <Bar dataKey="count" fill="#4f46e5" radius={[7, 7, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </section>

      <div className="dashboard-tables">
        <section className="data-panel">
          <div className="panel-heading">
            <div>
              <h3>Newest users</h3>
              <p>Recently registered accounts</p>
            </div>
          </div>
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Email address</th>
                </tr>
              </thead>
              <tbody>
                {stats.latestUsers?.length ? (
                  stats.latestUsers.map((user) => (
                    <tr key={user.id}>
                      <td>
                        <div className="name-cell">
                          <span>{user.name?.charAt(0)?.toUpperCase()}</span>
                          {user.name}
                        </div>
                      </td>
                      <td>{user.email}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="2" className="empty-cell">
                      No users to show yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
        <section className="data-panel">
          <div className="panel-heading">
            <div>
              <h3>Newest jobs</h3>
              <p>Recently added opportunities</p>
            </div>
          </div>
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  <th>Role</th>
                  <th>Company</th>
                </tr>
              </thead>
              <tbody>
                {stats.latestJobs?.length ? (
                  stats.latestJobs.map((job) => (
                    <tr key={job.id}>
                      <td>
                        <strong>{job.title}</strong>
                      </td>
                      <td>{job.company}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="2" className="empty-cell">
                      No jobs to show yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </AdminLayout>
  );
}

export default Dashboard;
